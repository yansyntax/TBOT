#!/bin/bash
# ================================================
#   INSTALLER BOT VPN WA — by yansyntax
#   Source: github.com/yansyntax/TBOT
# ================================================

set -e

# ── Warna ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ── Banner ──
clear
echo -e "${CYAN}"
echo "╔══════════════════════════════════════╗"
echo "║      BOT VPN WA — INSTALLER          ║"
echo "║      github.com/yansyntax/TBOT        ║"
echo "╚══════════════════════════════════════╝"
echo -e "${NC}"

# ── Helper ──
info()    { echo -e "${CYAN}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✗]${NC} $1"; exit 1; }
step()    { echo -e "\n${WHITE}━━━ $1 ━━━${NC}"; }

# ── Cek root ──
if [ "$EUID" -ne 0 ]; then
  error "Jalankan installer sebagai root: sudo bash install.sh"
fi

# ── Deteksi OS ──
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS=$ID
  OS_VERSION=$VERSION_ID
else
  error "OS tidak dikenali."
fi

case "$OS" in
  ubuntu|debian) PKG_MGR="apt-get" ;;
  centos|rhel|fedora) PKG_MGR="yum" ;;
  *) warn "OS $OS mungkin tidak sepenuhnya didukung. Melanjutkan..." ; PKG_MGR="apt-get" ;;
esac

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "1. UPDATE SISTEM"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
info "Update package list..."
$PKG_MGR update -y > /dev/null 2>&1
success "Sistem diperbarui"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "2. INSTALL DEPENDENSI SISTEM"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
info "Install curl, wget, git, python3, build-essential..."
$PKG_MGR install -y curl wget git unzip python3 python3-pip build-essential > /dev/null 2>&1
success "Dependensi sistem terinstall"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "3. CEK / INSTALL NODE.JS 20"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NODE_OK=false
if command -v node &>/dev/null; then
  NODE_VER=$(node -v | sed 's/v//' | cut -d. -f1)
  if [ "$NODE_VER" -ge 20 ]; then
    success "Node.js $(node -v) sudah terinstall"
    NODE_OK=true
  else
    warn "Node.js $(node -v) ditemukan tapi perlu >= v20. Upgrade..."
  fi
fi

if [ "$NODE_OK" = false ]; then
  info "Install Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
  $PKG_MGR install -y nodejs > /dev/null 2>&1
  success "Node.js $(node -v) berhasil diinstall"
fi

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "4. INSTALL PM2"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if command -v pm2 &>/dev/null; then
  success "PM2 sudah terinstall ($(pm2 -v))"
else
  info "Install PM2..."
  npm install -g pm2 > /dev/null 2>&1
  success "PM2 berhasil diinstall"
fi

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "5. DOWNLOAD BOT"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BOT_DIR="/root/wa-bot-vpn"

if [ -d "$BOT_DIR" ]; then
  warn "Folder $BOT_DIR sudah ada."
  echo -ne "${YELLOW}Hapus dan install ulang? (y/N): ${NC}"
  read -r CONFIRM
  if [[ "$CONFIRM" =~ ^[Yy]$ ]]; then
    # Stop PM2 jika jalan
    pm2 stop wa-bot-vpn 2>/dev/null || true
    pm2 delete wa-bot-vpn 2>/dev/null || true
    rm -rf "$BOT_DIR"
    info "Folder lama dihapus."
  else
    warn "Update/reinstall dibatalkan. Lanjut ke konfigurasi..."
    cd "$BOT_DIR"
    goto_config=true
  fi
fi

if [ -z "$goto_config" ]; then
  info "Download bot dari GitHub..."
  mkdir -p "$BOT_DIR"
  cd "$BOT_DIR"

  if wget -q "https://github.com/yansyntax/TBOT/raw/main/VPNBOT/wa.zip" -O /tmp/wa.zip; then
    success "Download berhasil"
  else
    error "Gagal download bot. Cek koneksi internet."
  fi

  info "Ekstrak file bot..."
  if command -v unzip &>/dev/null; then
    unzip -o /tmp/wa.zip -d /tmp/wa_extract > /dev/null 2>&1
  else
    python3 -c "import zipfile; zipfile.ZipFile('/tmp/wa.zip').extractall('/tmp/wa_extract')"
  fi

  # Pindahkan isi folder wa/ ke BOT_DIR
  if [ -d "/tmp/wa_extract/wa" ]; then
    cp -r /tmp/wa_extract/wa/. "$BOT_DIR/"
  else
    cp -r /tmp/wa_extract/. "$BOT_DIR/"
  fi
  rm -rf /tmp/wa_extract /tmp/wa.zip
  success "Bot berhasil diekstrak ke $BOT_DIR"
fi

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "6. KONFIGURASI BOT"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
cd "$BOT_DIR"

if [ ! -f "data/.avars.json" ]; then
  cp data/.avars.json.example data/.avars.json 2>/dev/null || true
fi

echo ""
echo -e "${CYAN}╔══════════════════════════════════╗"
echo -e "║      SETUP KONFIGURASI BOT       ║"
echo -e "╚══════════════════════════════════╝${NC}"
echo ""

# Nama bot
echo -ne "${WHITE}Nama Bot ${CYAN}(contoh: BOT VPN MURAH)${NC}: "
read -r BOT_NAME
BOT_NAME=${BOT_NAME:-"BOT VPN WA"}

# Nomor owner
echo -ne "${WHITE}Nomor WA Owner ${CYAN}(format 628xxx tanpa +)${NC}: "
read -r OWNER_PHONE
while [[ ! "$OWNER_PHONE" =~ ^62[0-9]{8,13}$ ]]; do
  echo -e "${RED}Format salah! Harus diawali 62 (contoh: 628123456789)${NC}"
  echo -ne "${WHITE}Nomor WA Owner: ${NC}"
  read -r OWNER_PHONE
done

# Pakasir slug
echo ""
echo -e "${YELLOW}┌─────────────────────────────────────┐"
echo -e "│  PAKASIR QRIS PAYMENT               │"
echo -e "│  Daftar di: app.pakasir.com          │"
echo -e "└─────────────────────────────────────┘${NC}"
echo -ne "${WHITE}Pakasir Project Slug: ${NC}"
read -r PAKASIR_SLUG

echo -ne "${WHITE}Pakasir API Key: ${NC}"
read -r PAKASIR_KEY

# Harga per protokol
echo ""
echo -e "${YELLOW}┌─────────────────────────────────────┐"
echo -e "│  HARGA VPN (Rp per hari)            │"
echo -e "└─────────────────────────────────────┘${NC}"
echo -ne "${WHITE}Harga Members (SSH/VMess/etc) per hari ${CYAN}[default: 3000]${NC}: "
read -r HARGA_MBR
HARGA_MBR=${HARGA_MBR:-3000}

echo -ne "${WHITE}Harga Reseller per hari ${CYAN}[default: 2000]${NC}: "
read -r HARGA_RSL
HARGA_RSL=${HARGA_RSL:-2000}

# Tulis .avars.json
cat > data/.avars.json << AVARS
{
  "bot_name": "${BOT_NAME}",
  "owner_phone": "${OWNER_PHONE}",
  "pakasir_slug": "${PAKASIR_SLUG}",
  "pakasir_api_key": "${PAKASIR_KEY}",
  "harga": {
    "members": {
      "SSH":    ${HARGA_MBR},
      "VMESS":  ${HARGA_MBR},
      "VLESS":  ${HARGA_MBR},
      "TROJAN": ${HARGA_MBR},
      "ZIVPN":  ${HARGA_MBR}
    },
    "reseller": {
      "SSH":    ${HARGA_RSL},
      "VMESS":  ${HARGA_RSL},
      "VLESS":  ${HARGA_RSL},
      "TROJAN": ${HARGA_RSL},
      "ZIVPN":  ${HARGA_RSL}
    }
  },
  "promo": {
    "active": false,
    "bonus_pct": 10
  }
}
AVARS

success "Konfigurasi tersimpan di data/.avars.json"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "7. INSTALL DEPENDENCIES NODE.JS"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
info "Install npm packages (mungkin 1-3 menit)..."
npm install --save 2>&1 | grep -E "added|warn|error" | head -5 || true
success "Packages berhasil diinstall"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "8. SETUP PM2 & AUTO-START"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
info "Setup PM2 startup..."
pm2 startup 2>/dev/null | tail -1 | bash > /dev/null 2>&1 || true
success "PM2 startup dikonfigurasi"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "9. PAIRING CODE — KONEKSI WA"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Bersihkan sessions/ lama agar pairing selalu fresh
if [ -d "sessions" ]; then
  info "Menghapus sesi lama (sessions/)..."
  rm -rf sessions/
fi
mkdir -p sessions/

echo ""
echo -e "${YELLOW}╔═══════════════════════════════════════════╗"
echo -e "║   CARA PAIRING KE WHATSAPP                ║"
echo -e "╠═══════════════════════════════════════════╣"
echo -e "║  1. Buka WhatsApp di HP kamu              ║"
echo -e "║  2. Ketuk titik 3 pojok kanan atas        ║"
echo -e "║  3. Pilih Perangkat Tertaut               ║"
echo -e "║  4. Tautkan Perangkat                     ║"
echo -e "║  5. Pilih 'Tautkan dengan nomor telepon'  ║"
echo -e "║  6. Masukkan 8-digit kode yang muncul     ║"
echo -e "╠═══════════════════════════════════════════╣"
echo -e "║  ⚠️  Setelah pairing berhasil:             ║"
echo -e "║     Tekan  Ctrl+C  untuk lanjut           ║"
echo -e "╚═══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Bot akan dijalankan langsung di terminal ini."
echo -e "Tunggu hingga kode 8 digit muncul, masukkan ke WA,"
echo -e "lalu tekan ${WHITE}Ctrl+C${CYAN} setelah pesan 'Terhubung' muncul.${NC}"
echo ""
echo -ne "${WHITE}Siap? Tekan ENTER untuk mulai pairing...${NC}"
read -r

echo ""
echo -e "${YELLOW}⏳ Menjalankan bot... tunggu Pairing Code...${NC}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Jalankan langsung (tanpa pipe) agar WebSocket & terminal berjalan normal
node index.js || true

echo ""
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -ne "${WHITE}Apakah pairing sudah berhasil? (y/N): ${NC}"
read -r PAIRED
if [[ ! "$PAIRED" =~ ^[Yy]$ ]]; then
  warn "Pairing belum selesai."
  echo ""
  echo -e "  Jalankan ulang pairing manual:"
  echo -e "  ${CYAN}cd $BOT_DIR && rm -rf sessions/ && node index.js${NC}"
  echo ""
  echo -ne "${WHITE}Tetap lanjut pasang PM2? (y/N): ${NC}"
  read -r CONTINUE_PM2
  if [[ ! "$CONTINUE_PM2" =~ ^[Yy]$ ]]; then
    echo ""
    echo -e "${CYAN}Selesai. Jalankan pairing dulu, lalu:${NC}"
    echo -e "  ${WHITE}pm2 start $BOT_DIR/index.js --name wa-bot-vpn${NC}"
    echo ""
    exit 0
  fi
fi

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
step "10. JALANKAN BOT DENGAN PM2"
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
pm2 delete wa-bot-vpn 2>/dev/null || true
pm2 start index.js --name wa-bot-vpn --restart-delay=3000
pm2 save > /dev/null 2>&1

success "Bot berjalan dengan PM2!"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
echo ""
echo -e "${GREEN}"
echo "╔══════════════════════════════════════════╗"
echo "║   ✅  INSTALASI SELESAI!                 ║"
echo "╠══════════════════════════════════════════╣"
echo "║                                          ║"
echo "║  📁 Lokasi bot : /root/wa-bot-vpn        ║"
echo "║                                          ║"
echo "║  📋 PERINTAH PM2:                        ║"
echo "║  pm2 status          → cek status        ║"
echo "║  pm2 logs wa-bot-vpn → lihat log         ║"
echo "║  pm2 restart wa-bot-vpn → restart        ║"
echo "║  pm2 stop wa-bot-vpn → stop bot          ║"
echo "║                                          ║"
echo "║  💬 PERINTAH DI WA:                      ║"
echo "║  menu   → menu utama                     ║"
echo "║  .admin → panel admin (owner only)       ║"
echo "║  .saldo → cek saldo                      ║"
echo "║                                          ║"
echo "║  ➕ TAMBAH SERVER VPN:                   ║"
echo "║  Kirim .admin di WA → pilih 3            ║"
echo "║                                          ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "${CYAN}Bot dibuat oleh: yansyntax${NC}"
echo -e "${CYAN}GitHub: github.com/yansyntax/TBOT${NC}"
echo ""
