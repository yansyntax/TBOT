// index.js — WhatsApp VPN Reseller Bot v1.0
// Node.js >= 20 | Baileys | Pakasir QRIS
'use strict';

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  makeCacheableSignalKeyStore,
  Browsers
} = require('@whiskeysockets/baileys');

const pino      = require('pino');
const chalk     = require('chalk');
const readline  = require('readline');
const path      = require('path');
const fs        = require('fs');

/* ── Config ── */
const AVARS_PATH = path.join(__dirname, 'data', '.avars.json');
let avars = {};
if (fs.existsSync(AVARS_PATH)) {
  try { avars = JSON.parse(fs.readFileSync(AVARS_PATH, 'utf8')); }
  catch (e) { console.error('[BOT] ❌ Gagal baca .avars.json:', e.message); }
} else {
  console.error('[BOT] ❌ data/.avars.json tidak ditemukan! Copy dari .avars.json.example lalu isi konfigurasi.');
  process.exit(1);
}

global.avars = avars;

/* ── Prompt terminal ── */
function ask(q) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(res => rl.question(q, ans => { rl.close(); res(ans.trim()); }));
}

/* ── Koneksi utama ── */
async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('./sessions');
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(chalk.cyan(`[BOT] Baileys WA v${version.join('.')}, isLatest: ${isLatest}`));

  /* ── Ambil nomor owner untuk pairing ── */
  let pairingPhone = (avars.owner_phone || '').replace(/[^0-9]/g, '');
  let pairingRequested = false;

  const bot = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
    },
    printQRInTerminal: false,
    mobile: false,
    browser: Browsers.ubuntu('Chrome'),
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    getMessage: async () => undefined
  });

  /* ── Events ── */
  bot.ev.on('creds.update', saveCreds);

  bot.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    /* ── Pairing Code — dipanggil saat koneksi WS mulai terbuka ── */
    if (connection === 'connecting' && !bot.authState.creds.registered && !pairingRequested) {
      pairingRequested = true;
      if (!pairingPhone) pairingPhone = (await ask('📱 Masukkan nomor WA (format 628xxx): ')).replace(/[^0-9]/g, '');
      /* Baileys butuh ~1-2 detik setelah 'connecting' sebelum bisa request pairing */
      setTimeout(async () => {
        try {
          const code = await bot.requestPairingCode(pairingPhone);
          console.log(chalk.yellow(`\n🎁 Pairing Code: ${chalk.bold(code)}\n`));
          console.log(chalk.gray('   Masukkan kode ini di WhatsApp: Setelan → Perangkat Tertaut → Tautkan Perangkat\n'));
        } catch (e) {
          console.error('[BOT] ❌ Gagal request pairing code:', e.message);
          pairingRequested = false; /* izinkan retry jika reconnect */
        }
      }, 2000);
    }

    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.red(`[BOT] Koneksi terputus. Reconnect: ${shouldReconnect}`));
      if (shouldReconnect) setTimeout(() => connectToWhatsApp(), 3000);
      else { console.log(chalk.red('[BOT] Logged out. Hapus folder sessions/ lalu jalankan ulang.')); process.exit(1); }
    } else if (connection === 'open') {
      console.log(chalk.green(`\n[${avars.bot_name || 'BOT VPN WA'}] ✅ Terhubung ke WhatsApp! 🚀\n`));

      /* ── Inisialisasi DB & owner ── */
      const { dbRunSync } = require('./data/db');
      if (avars.owner_phone) {
        const ownerId = avars.owner_phone.replace(/[^0-9]/g, '');
        dbRunSync("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'admin')", [ownerId]);
        dbRunSync("UPDATE users SET role='admin' WHERE chat_id=? AND role != 'admin'", [ownerId]);
      }

      /* ── Services ── */
      try {
        const { startPaymentChecker } = require('./services/paymentChecker');
        startPaymentChecker(bot);
        console.log('[BOT] ✅ Payment checker aktif');
      } catch (e) { console.error('[BOT] ❌ payment checker:', e.message); }

      try {
        const { startExpiredNotif } = require('./services/expiredNotif');
        startExpiredNotif(bot);
        console.log('[BOT] ✅ Expired notif aktif');
      } catch (e) { console.error('[BOT] ❌ expired notif:', e.message); }

      try {
        const { startAutoDelete } = require('./services/autoDelete');
        startAutoDelete(bot);
        console.log('[BOT] ✅ Auto-delete aktif');
      } catch (e) { console.error('[BOT] ❌ auto-delete:', e.message); }
    }
  });

  /* ── Handler Pesan ── */
  const handler = require('./handler');
  bot.ev.on('messages.upsert', async ({ messages, type }) => {
    /* Proses semua tipe pesan masuk (notify = baru, append = history) */
    for (const msg of messages) {
      if (!msg.message) continue;
      if (msg.key.fromMe) continue; /* skip pesan dari bot sendiri */

      /* Debug: tampilkan di log */
      const dbgBody = (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption || ''
      ).slice(0, 80);
      const dbgFrom = (msg.key.remoteJid || '').replace('@s.whatsapp.net','');
      console.log(`[MSG] type=${type} from=${dbgFrom} body="${dbgBody}"`);

      try { await handler(bot, msg); } catch (e) { console.error('[HANDLER] ❌', e.message, '\n', e.stack); }
    }
  });
}

process.on('uncaughtException',  e => console.error('[BOT] 🔥 uncaughtException:', e.stack || e.message));
process.on('unhandledRejection', e => console.error('[BOT] 🔥 unhandledRejection:', e?.stack || e));

connectToWhatsApp();
