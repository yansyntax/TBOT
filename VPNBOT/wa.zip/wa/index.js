// index.js — WhatsApp VPN Reseller Bot v1.0
// Node.js >= 20 | Baileys | Pakasir QRIS
'use strict';

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason
} = require('@whiskeysockets/baileys');

const pino     = require('pino');
const chalk    = require('chalk');
const readline = require('readline');
const path     = require('path');
const fs       = require('fs');

/* ── Config ── */
const AVARS_PATH = path.join(__dirname, 'data', '.avars.json');
let avars = {};
if (fs.existsSync(AVARS_PATH)) {
  try { avars = JSON.parse(fs.readFileSync(AVARS_PATH, 'utf8')); }
  catch (e) { console.error('[BOT] ❌ Gagal baca .avars.json:', e.message); }
} else {
  console.error('[BOT] ❌ data/.avars.json tidak ditemukan!');
  process.exit(1);
}
global.avars = avars;

/* ── Prompt terminal ── */
async function question(prompt) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(res => rl.question(prompt, ans => { rl.close(); res(ans.trim()); }));
}

/* ── Koneksi utama ── */
async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('./sessions');
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(chalk.cyan(`[BOT] Baileys WA v${version.join('.')}, isLatest: ${isLatest}`));

  /* ── Buat socket — pakai auth: state langsung (tanpa caching) ── */
  const bot = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state,
    browser: ['Ubuntu', 'Chrome', '20.0.0.0'],
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    getMessage: async () => undefined
  });

  /* ── Pairing Code — dipanggil langsung setelah makeWASocket ── */
  if (!bot.authState.creds.registered) {
    let phone = (avars.owner_phone || '').replace(/[^0-9]/g, '');
    if (!phone) phone = (await question('📱 Masukkan nomor WA (format 628xxx): ')).replace(/[^0-9]/g, '');
    try {
      const code = await bot.requestPairingCode(phone);
      console.log(chalk.yellow(`\n🎁 Pairing Code: ${chalk.bold(code)}\n`));
      console.log(chalk.gray('   Masukkan kode ini di WhatsApp → Setelan → Perangkat Tertaut → Tautkan Perangkat\n'));
    } catch (e) {
      console.error('[BOT] ❌ Gagal pairing code:', e.message);
    }
  }

  /* ── Simpan sesi ── */
  bot.ev.on('creds.update', saveCreds);

  /* ── Status koneksi ── */
  bot.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {
      const code    = lastDisconnect?.error?.output?.statusCode;
      const logout  = code === DisconnectReason.loggedOut;
      console.log(chalk.red(`[BOT] Koneksi terputus (code ${code}). Reconnect: ${!logout}`));
      if (logout) {
        console.log(chalk.red('[BOT] Logged out — hapus folder sessions/ lalu jalankan ulang.'));
        process.exit(1);
      } else {
        setTimeout(() => connectToWhatsApp(), 3000);
      }

    } else if (connection === 'open') {
      console.log(chalk.green(`\n[${avars.bot_name || 'BOT VPN WA'}] ✅ Terhubung ke WhatsApp! 🚀\n`));

      /* ── Set owner sebagai admin ── */
      const { dbRunSync } = require('./data/db');
      if (avars.owner_phone) {
        const ownerId = avars.owner_phone.replace(/[^0-9]/g, '');
        dbRunSync("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'admin')", [ownerId]);
        dbRunSync("UPDATE users SET role='admin' WHERE chat_id=?", [ownerId]);
      }

      /* ── Mulai services ── */
      try { const { startPaymentChecker } = require('./services/paymentChecker'); startPaymentChecker(bot); console.log('[BOT] ✅ Payment checker aktif'); }
      catch (e) { console.error('[BOT] ❌ Payment checker:', e.message); }

      try { const { startExpiredNotif } = require('./services/expiredNotif'); startExpiredNotif(bot); console.log('[BOT] ✅ Expired notif aktif'); }
      catch (e) { console.error('[BOT] ❌ Expired notif:', e.message); }

      try { const { startAutoDelete } = require('./services/autoDelete'); startAutoDelete(bot); console.log('[BOT] ✅ Auto-delete aktif'); }
      catch (e) { console.error('[BOT] ❌ Auto-delete:', e.message); }
    }
  });

  /* ── Handler pesan masuk ── */
  const handler = require('./handler');
  bot.ev.on('messages.upsert', async (m) => {
    /* Hanya proses pesan BARU — 'append' adalah pesan history lama, skip */
    if (m.type !== 'notify') return;

    const messages = m.messages || [];
    for (const msg of messages) {
      if (!msg.message) continue;
      if (msg.key.fromMe) continue;

      /* Log debug */
      const body = (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption || ''
      ).slice(0, 80);
      const from = (msg.key.remoteJid || '').replace('@s.whatsapp.net', '');
      console.log(`[MSG] from=${from} body="${body}"`);

      try { await handler(bot, msg); }
      catch (e) { console.error('[HANDLER] ❌', e.message, '\n', e.stack); }
    }
  });
}

process.on('uncaughtException',  e => console.error('[BOT] 🔥 uncaughtException:', e.stack || e.message));
process.on('unhandledRejection', e => console.error('[BOT] 🔥 unhandledRejection:', e?.stack || e));

connectToWhatsApp();
