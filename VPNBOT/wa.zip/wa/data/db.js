// data/db.js — SQLite database (sqlite3 + Promise helpers)
'use strict';

const sqlite3 = require('sqlite3').verbose();
const path    = require('path');

const db = new sqlite3.Database(path.join(__dirname, 'wabotdb.db'), (err) => {
  if (err) console.error('[DB] ❌', err.message);
  else console.log('[DB] ✅ Database ready: wabotdb.db');
});

db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL');
  db.run('PRAGMA synchronous = NORMAL');

  db.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id    TEXT PRIMARY KEY,
    saldo      INTEGER DEFAULT 0,
    role       TEXT    DEFAULT 'members',
    created_at TEXT    DEFAULT (datetime('now','localtime'))
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id      TEXT,
    order_id     TEXT UNIQUE,
    amount       INTEGER DEFAULT 0,
    status       TEXT    DEFAULT 'pending',
    created_at   TEXT    DEFAULT (datetime('now','localtime')),
    product_type TEXT    DEFAULT '',
    username     TEXT    DEFAULT '',
    expired_at   TEXT    DEFAULT '',
    server_ip    TEXT    DEFAULT '',
    is_deleted   INTEGER DEFAULT 0
  )`);

  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat    ON transactions(chat_id, status)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_order   ON transactions(order_id)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_deleted ON transactions(is_deleted, expired_at, status)`);

  db.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id     TEXT,
    order_id    TEXT,
    days_before INTEGER,
    sent_at     TEXT,
    UNIQUE(order_id, days_before)
  )`);

  db.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);
});

/* ── Promise helpers ── */
function dbRun(sql, params = []) {
  return new Promise((res, rej) =>
    db.run(sql, params, function(err) { err ? rej(err) : res(this); })
  );
}
function dbGet(sql, params = []) {
  return new Promise((res, rej) =>
    db.get(sql, params, (err, row) => err ? rej(err) : res(row || null))
  );
}
function dbAll(sql, params = []) {
  return new Promise((res, rej) =>
    db.all(sql, params, (err, rows) => err ? rej(err) : res(rows || []))
  );
}

/* ── Sync-style wrappers (fire-and-forget) ── */
function dbRunSync(sql, params = []) {
  db.run(sql, params, err => { if (err) console.error('[DB]', err.message); });
}

module.exports = { db, dbRun, dbGet, dbAll, dbRunSync };
