// services/autoDelete.js — Auto hapus akun expired (tiap 6 jam)
'use strict';

const { db, dbRunSync } = require('../data/db');
const { executeScriptRemote, decreaseServerUsage } = require('./ssh-exec');

const HAPUS_SCRIPT = {
  SSH:'hapusSSH', VMESS:'hapusVME', VLESS:'hapusVLE', TROJAN:'hapusTRO', ZIVPN:'hapusZIVPN'
};
const LABEL = {
  SSH:'⚪ SSH/OpenVPN', VMESS:'🔵 xRay VMess',
  VLESS:'🟡 xRay VLess', TROJAN:'🟠 xRay Trojan', ZIVPN:'🟢 UDP ZivPN'
};

function getExpiredAccounts() {
  return new Promise((res, rej) => {
    db.all(`
      SELECT server_ip, product_type, username, MAX(expired_at) as latest_exp
      FROM transactions
      WHERE status='completed' AND is_deleted=0
        AND expired_at IS NOT NULL AND expired_at != ''
        AND username IS NOT NULL AND username != ''
        AND product_type NOT IN ('', 'TOPUP')
        AND product_type NOT LIKE 'TRIAL%'
        AND product_type NOT LIKE 'RENEW%'
      GROUP BY server_ip, product_type, username
      HAVING datetime(latest_exp) < datetime('now', 'localtime')
    `, [], (err, rows) => err ? rej(err) : res(rows||[]));
  });
}

function processOne(bot, row) {
  return new Promise(resolve => {
    const script = HAPUS_SCRIPT[row.product_type];
    if (!script) return resolve('SKIP');

    executeScriptRemote(row.server_ip, script, [row.username], (err, output) => {
      if (err) { console.error(`[autoDelete] SSH error ${row.username}:`, err.message); return resolve('ERROR'); }

      const line   = (output||'').split('\n').find(l => l.startsWith('STATUS:'));
      const status = line ? line.replace('STATUS:','').trim() : 'UNKNOWN';

      if (status === 'DELETED' || status === 'NOT_FOUND') {
        dbRunSync(
          "UPDATE transactions SET is_deleted=1 WHERE server_ip=? AND product_type=? AND username=? AND status='completed'",
          [row.server_ip, row.product_type, row.username]
        );
        decreaseServerUsage(row.server_ip);

        /* Notif user */
        const { send } = require('../handler');
        db.all(
          "SELECT DISTINCT chat_id FROM transactions WHERE server_ip=? AND product_type=? AND username=? AND status='completed'",
          [row.server_ip, row.product_type, row.username],
          (e, users) => {
            (users||[]).forEach(u => {
              send(bot, `${u.chat_id}@s.whatsapp.net`,
`🗑 *Akun Kamu Telah Dihapus*

${LABEL[row.product_type]||row.product_type}
👤 Username : \`${row.username}\`

Akun melewati masa aktif dan otomatis dihapus dari server.
Ketik *menu* untuk order akun baru.`
              ).catch(()=>{});
            });
          }
        );
        console.log(`[autoDelete] ✅ ${status}: ${row.product_type}/${row.username}@${row.server_ip}`);
      }
      resolve(status);
    });
  });
}

async function runAutoDelete(bot) {
  let rows;
  try { rows = await getExpiredAccounts(); }
  catch (e) { console.error('[autoDelete] getExpiredAccounts:', e.message); return; }

  if (!rows.length) { console.log('[autoDelete] Tidak ada akun expired.'); return; }

  console.log(`[autoDelete] Memproses ${rows.length} akun expired...`);
  for (const row of rows) {
    await processOne(bot, row);
    await new Promise(r => setTimeout(r, 1500));
  }
  console.log('[autoDelete] ✅ Selesai.');
}

function startAutoDelete(bot) {
  setTimeout(() => runAutoDelete(bot), 3 * 60 * 1000);
  setInterval(() => runAutoDelete(bot), 6 * 60 * 60 * 1000);
  console.log('[autoDelete] ✅ Aktif (cek tiap 6 jam)');
}

module.exports = { startAutoDelete };
