// services/paymentChecker.js — Cek status pembayaran Pakasir
'use strict';

const axios = require('axios');
const fs    = require('fs');
const path  = require('path');
const { db, dbRun, dbGet, dbRunSync } = require('../data/db');

function getAvars() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); }
  catch { return global.avars || {}; }
}

const QRIS_TTL_MS    = 10 * 60 * 1000;
const CHECK_INTERVAL = 8000;

const pendingOrders = new Map();
function addPendingOrder(orderId, info) { pendingOrders.set(orderId, { ...info, createdAt: info.createdAt || Date.now() }); }
function removePendingOrder(orderId)    { pendingOrders.delete(orderId); }
module.exports.addPendingOrder    = addPendingOrder;
module.exports.removePendingOrder = removePendingOrder;

async function fetchStatus(orderId, amount) {
  const av = getAvars();
  try {
    const url = `https://app.pakasir.com/api/transactiondetail?project=${av.pakasir_slug}&amount=${amount}&order_id=${orderId}&api_key=${av.pakasir_api_key}`;
    const res = await axios.get(url, { timeout: 8000 });
    return res.data?.transaction || { status: 'not_found' };
  } catch { return { status: 'error' }; }
}

async function processCompleted(bot, orderId, info) {
  removePendingOrder(orderId);
  try { require('./qris').clearQrisCountdown(orderId); } catch {}

  dbRunSync("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);

  const { send, doCreateAccount } = require('../handler');
  const av = getAvars();
  const formatRp = n => 'Rp ' + Number(n).toLocaleString('id-ID');

  /* Notif admin */
  if (av.owner_phone) {
    send(bot, `${av.owner_phone.replace(/[^0-9]/g,'')}@s.whatsapp.net`,
      `🔔 *PEMBAYARAN MASUK!*\n\n📦 ${info.productName||''}\n📱 ${info.phoneId}\n💰 ${formatRp(info.amount)}\n🧾 ${orderId}`
    ).catch(()=>{});
  }

  if (info.accountCreate) {
    return doCreateAccount(bot, info.jid, info.phoneId, info.accountCreate);
  }

  /* Top up saldo */
  const bonus = av.promo?.active
    ? Math.round(info.amount * (1 + (av.promo.bonus_pct||0) / 100))
    : info.amount;

  dbRunSync("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'members')", [info.phoneId]);
  dbRunSync('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [bonus, info.phoneId]);

  const u = await dbGet('SELECT saldo FROM users WHERE chat_id=?', [info.phoneId]);

  send(bot, info.jid,
`✅ *PEMBAYARAN BERHASIL!*

🧾 Order   : ${orderId}
💰 Nominal : ${formatRp(info.amount)}${bonus > info.amount ? `\n🎁 Bonus   : +${formatRp(bonus - info.amount)}` : ''}
💳 Masuk   : *${formatRp(bonus)}*
💰 Saldo   : *${formatRp(u?.saldo||0)}*

Ketik *menu* untuk mulai order.`
  ).catch(()=>{});
}

/* Manual cek: .cek <orderId> */
async function handleManualCek(bot, jid, phoneId, orderId) {
  const { send } = require('../handler');
  const info = pendingOrders.get(orderId);
  if (!info) return send(bot, jid, `❌ Order *${orderId}* tidak ditemukan atau sudah selesai.`);
  const tx = await fetchStatus(orderId, info.amount);
  if (tx.status === 'completed') return processCompleted(bot, orderId, info);
  const map = { error:'Gagal cek', not_found:'Belum dibayar', canceled:'Dibatalkan', expired:'Kadaluarsa' };
  send(bot, jid, `⏳ Status: *${map[tx.status]||'Pending'}*\n\nBayar dulu lalu cek lagi, atau tunggu otomatis.`);
}
module.exports.handleManualCek = handleManualCek;

function startPaymentChecker(bot) {
  const av = getAvars();
  if (!av.pakasir_slug || !av.pakasir_api_key) {
    return console.warn('[paymentChecker] ⚠️ Pakasir belum dikonfigurasi, checker dinonaktifkan.');
  }

  const { send } = require('../handler');
  console.log(`[paymentChecker] ✅ Aktif (interval ${CHECK_INTERVAL}ms)`);

  setInterval(async () => {
    if (!pendingOrders.size) return;
    for (const [orderId, info] of [...pendingOrders.entries()]) {
      const age = Date.now() - info.createdAt;
      if (age > QRIS_TTL_MS) {
        removePendingOrder(orderId);
        dbRunSync("UPDATE transactions SET status='expired' WHERE order_id=?", [orderId]);
        try { require('./qris').clearQrisCountdown(orderId); } catch {}
        send(bot, info.jid, `⏰ Order *${orderId}* kadaluarsa.\nKetik *menu* untuk order baru.`).catch(()=>{});
        continue;
      }
      const tx = await fetchStatus(orderId, info.amount);
      if (tx.status === 'completed') {
        await processCompleted(bot, orderId, info);
      } else if (tx.status === 'canceled' || tx.status === 'expired') {
        removePendingOrder(orderId);
        dbRunSync("UPDATE transactions SET status=? WHERE order_id=?", [tx.status, orderId]);
        try { require('./qris').clearQrisCountdown(orderId); } catch {}
        send(bot, info.jid, `❌ Order *${orderId}* ${tx.status}.\nKetik *menu* untuk order baru.`).catch(()=>{});
      }
    }
  }, CHECK_INTERVAL);
}
module.exports.startPaymentChecker = startPaymentChecker;
