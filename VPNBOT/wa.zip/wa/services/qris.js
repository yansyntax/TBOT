// services/qris.js — QRIS via Pakasir untuk WhatsApp bot
'use strict';

const axios  = require('axios');
const QRCode = require('qrcode');
const fs     = require('fs');
const path   = require('path');
const { dbRunSync } = require('../data/db');

function getAvars() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); }
  catch { return global.avars || {}; }
}

const QRIS_EXPIRY_MS = 10 * 60 * 1000;
const countdownIntervals = new Map();

function clearQrisCountdown(orderId) {
  const iv = countdownIntervals.get(orderId);
  if (iv) { clearInterval(iv); countdownIntervals.delete(orderId); }
}
module.exports.clearQrisCountdown = clearQrisCountdown;

async function generateQRIS(bot, jid, phoneId, amount, pendingInfo = {}) {
  const av      = getAvars();
  const orderId = `${phoneId}_${Date.now()}`;
  const { send } = require('../handler');

  if (!av.pakasir_slug || !av.pakasir_api_key) {
    return send(bot, jid, '❌ Konfigurasi payment belum lengkap. Hubungi admin.');
  }

  try {
    const res = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
      project:  av.pakasir_slug,
      order_id: orderId,
      amount,
      api_key:  av.pakasir_api_key
    }, { timeout: 15000 });

    const txData = res.data;
    if (!txData.payment?.payment_number) throw new Error('Gagal dapat QR string dari Pakasir');

    const qrBuffer = await QRCode.toBuffer(txData.payment.payment_number, {
      width: 400, margin: 2
    });

    dbRunSync(
      "INSERT OR IGNORE INTO transactions (chat_id, order_id, amount, status, product_type) VALUES (?, ?, ?, 'pending', ?)",
      [phoneId, orderId, amount, pendingInfo.productType || '']
    );

    const isTopup   = pendingInfo.productType === 'TOPUP';
    const formatRp  = n => 'Rp ' + Number(n).toLocaleString('id-ID');

    const caption =
`╔══════════════════╗
║  💳 QRIS PEMBAYARAN
╚══════════════════╝

${isTopup ? '💰 *TOP UP SALDO*' : `📦 *${pendingInfo.productName||''}*`}
💵 Nominal  : *${formatRp(amount)}*
🧾 Order ID : ${orderId}
⏰ Berlaku  : *10 menit*

Scan QR di atas pakai DANA/OVO/GoPay/m-Banking.
⚡ ${isTopup ? 'Saldo otomatis masuk' : 'Akun otomatis dibuat'} setelah lunas!

Ketik *.cek ${orderId}* untuk cek manual.`;

    /* Kirim gambar QR */
    await bot.sendMessage(jid, { image: qrBuffer, caption, mimetype: 'image/png' })
      .catch(() => send(bot, jid, caption));

    /* Register ke payment checker */
    const { addPendingOrder } = require('./paymentChecker');
    addPendingOrder(orderId, {
      phoneId, jid, amount,
      productType:   pendingInfo.productType   || '',
      productName:   pendingInfo.productName   || 'Top Up Saldo',
      accountCreate: pendingInfo.accountCreate || null,
      createdAt:     Date.now()
    });

    /* Countdown tiap 2 menit */
    let menit = 10;
    const iv = setInterval(() => {
      menit -= 2;
      if (menit <= 0) {
        clearInterval(iv);
        countdownIntervals.delete(orderId);
        send(bot, jid, `⏰ Order *${orderId}* sudah kadaluarsa.\nKetik *menu* untuk order baru.`).catch(()=>{});
        return;
      }
      send(bot, jid, `⏳ QRIS masih berlaku *${menit} menit* lagi.\nKetik *.cek ${orderId}* untuk cek status.`).catch(()=>{});
    }, 2 * 60 * 1000);

    countdownIntervals.set(orderId, iv);

  } catch (err) {
    console.error('[generateQRIS] ❌', err.message);
    send(bot, jid, `❌ Gagal membuat QRIS: ${err.message}`);
  }
}

module.exports.generateQRIS = generateQRIS;
