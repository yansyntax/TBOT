// services/expiredNotif.js — Notif expired 3 hari & 1 hari sebelum
'use strict';

const { db, dbRunSync } = require('../data/db');

const LABEL = {
  SSH:'⚪ SSH/OpenVPN', VMESS:'🔵 xRay VMess',
  VLESS:'🟡 xRay VLess', TROJAN:'🟠 xRay Trojan', ZIVPN:'🟢 UDP ZivPN'
};

function cekDanKirim(bot) {
  const { send } = require('../handler');

  [3, 1].forEach(days => {
    db.all(`
      SELECT t.chat_id, t.order_id, t.product_type, t.username, t.expired_at
      FROM transactions t
      WHERE t.status = 'completed'
        AND t.is_deleted = 0
        AND t.expired_at IS NOT NULL AND t.expired_at != ''
        AND t.product_type NOT IN ('', 'TOPUP')
        AND t.product_type NOT LIKE 'TRIAL%'
        AND date(t.expired_at) = date('now', 'localtime', '+${days} days')
    `, [], (err, rows) => {
      if (err || !rows?.length) return;
      rows.forEach((row, i) => {
        db.get('SELECT id FROM notif_log WHERE order_id=? AND days_before=?', [row.order_id, days], (e, found) => {
          if (found) return;
          setTimeout(() => {
            const jid   = `${row.chat_id}@s.whatsapp.net`;
            const label = LABEL[row.product_type] || row.product_type;
            const emoji = days === 1 ? '🔴' : '🟡';
            send(bot, jid,
`${emoji} *PERINGATAN EXPIRED!*

${label}
👤 Username : \`${row.username||'-'}\`
📅 Expired  : *${row.expired_at?.slice(0,10)||'-'}*
⏳ Sisa     : *${days} hari lagi*

Segera perpanjang! Ketik *menu* untuk order.`
            ).catch(()=>{});
            dbRunSync("INSERT OR IGNORE INTO notif_log (chat_id, order_id, days_before, sent_at) VALUES (?, ?, ?, datetime('now','localtime'))",
              [row.chat_id, row.order_id, days]);
          }, i * 500);
        });
      });
    });
  });
}

function startExpiredNotif(bot) {
  setTimeout(() => cekDanKirim(bot), 30000);
  setInterval(() => cekDanKirim(bot), 60 * 60 * 1000);
  console.log('[expiredNotif] ✅ Aktif (cek tiap 1 jam)');
}

module.exports = { startExpiredNotif };
