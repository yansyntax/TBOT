// services/ssh-exec.js — SSH remote executor
'use strict';

const { Client } = require('ssh2');
const fs   = require('fs');
const path = require('path');

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch { return []; }
}

function cleanOutput(raw) {
  return (raw || '').split('\n').filter(l => {
    const t = l.trim();
    if (!t) return false;
    if (/TERM environment/i.test(t)) return false;
    if (/tput:/i.test(t)) return false;
    if (/setlocale/i.test(t)) return false;
    if (/cannot change locale/i.test(t)) return false;
    if (/^bash:.*warning:/i.test(t)) return false;
    return true;
  }).join('\n').trim();
}

function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const servers      = getServers();
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error(`Server ${serverIp} tidak terdaftar`));

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`Script ${scriptFileName} tidak ditemukan`));

  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  const conn = new Client();

  const safeArgs = args.map(a => String(a).replace(/'/g, "'\\''"));
  const isRoot   = (serverConfig.username || 'root') === 'root';
  const tmpFile  = `/tmp/_wabot_${Date.now()}`;
  const runCmd   = isRoot
    ? `bash ${tmpFile} ${safeArgs.join(' ')}`
    : `echo '${(serverConfig.pass || '').replace(/'/g, "'\\''")}' | sudo -S bash ${tmpFile} ${safeArgs.join(' ')}`;
  const command = `cat > ${tmpFile} && ${runCmd}; rm -f ${tmpFile}`;

  const TIMEOUT = setTimeout(() => {
    conn.end();
    callback(new Error('Koneksi SSH timeout (30 detik)'));
  }, 30000);

  conn.on('ready', () => {
    conn.exec(command, (err, stream) => {
      if (err) { clearTimeout(TIMEOUT); conn.end(); return callback(err); }

      let output = '';
      stream.on('data', d => { output += d; });
      stream.stderr.on('data', d => {
        const line = d.toString();
        if (!line.includes('[sudo]') && !line.includes('password for')) output += line;
      });
      stream.on('close', () => {
        clearTimeout(TIMEOUT);
        conn.end();
        callback(null, cleanOutput(output));
      });
      stream.end(scriptContent);
    });
  })
  .on('keyboard-interactive', (_n, _i, _l, prompts, finish) => {
    finish(prompts.map(() => serverConfig.pass));
  })
  .on('error', err => { clearTimeout(TIMEOUT); callback(err); })
  .connect({
    host:         serverIp,
    port:         22,
    username:     serverConfig.username || 'root',
    password:     serverConfig.pass,
    tryKeyboard:  true,
    readyTimeout: 25000
  });
}

function increaseServerUsage(serverIp) {
  const servers = getServers();
  const server  = servers.find(s => s.ip === serverIp);
  if (!server) return;
  server.used  = (server.used || 0) + 1;
  server.limit = server.limit || 999;
  const file = path.join(__dirname, '../data/server.js');
  fs.writeFileSync(file, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
}

function decreaseServerUsage(serverIp) {
  const servers = getServers();
  const server  = servers.find(s => s.ip === serverIp);
  if (!server) return;
  server.used = Math.max(0, (server.used || 1) - 1);
  const file = path.join(__dirname, '../data/server.js');
  fs.writeFileSync(file, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
}

module.exports = { executeScriptRemote, increaseServerUsage, decreaseServerUsage };
