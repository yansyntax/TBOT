# WhatsApp VPN Reseller Bot

Bot reseller VPN untuk WhatsApp menggunakan Baileys + Pakasir QRIS.

## Prasyarat

- Ubuntu/Debian VPS
- Node.js >= 20
- npm
- Python3 + build-essential (untuk compile sqlite3)

## Instalasi di VPS

```bash
# 1. Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. Install build tools (untuk sqlite3)
sudo apt-get install -y python3 build-essential

# 3. Upload folder wa-bot-vpn ke VPS, lalu masuk ke folder
cd wa-bot-vpn

# 4. Install dependencies
npm install

# 5. Copy dan isi konfigurasi
cp data/.avars.json.example data/.avars.json
nano data/.avars.json
```

## Konfigurasi (data/.avars.json)

```json
{
  "bot_name": "BOT VPN WA",
  "owner_phone": "628xxxxxxxxxx",       ← nomor WA owner (format 628xxx)
  "pakasir_slug": "slug-project-kamu",  ← dari dashboard Pakasir
  "pakasir_api_key": "api-key-kamu",    ← dari dashboard Pakasir
  "harga": {
    "members": {
      "SSH": 3000, "VMESS": 3000, "VLESS": 3000, "TROJAN": 3000, "ZIVPN": 3000
    },
    "reseller": {
      "SSH": 2000, "VMESS": 2000, "VLESS": 2000, "TROJAN": 2000, "ZIVPN": 2000
    }
  },
  "promo": {
    "active": false,
    "bonus_pct": 10
  }
}
```

## Tambah Server VPN

Setelah bot nyala, ketik di WA owner:
```
.admin
```
Pilih **3 (Tambah Server)** lalu masukkan:
```
NamaServer|IP|username|password|limit
Contoh: IDN-RumahWeb|203.194.115.138|root|Password123|60
```

## Jalankan Bot

```bash
# Pertama kali — akan minta pairing code
node index.js
```

Ikuti instruksi pairing code di terminal, masukkan ke WhatsApp:
**Setelan → Perangkat Tertaut → Tautkan Perangkat → Tautkan dengan nomor telepon**

## Jalankan dengan PM2 (auto-restart)

```bash
# Install PM2
npm install -g pm2

# Jalankan
pm2 start index.js --name wa-bot-vpn

# Auto-start saat VPS reboot
pm2 startup
pm2 save

# Lihat log
pm2 logs wa-bot-vpn

# Restart
pm2 restart wa-bot-vpn
```

## Perintah Bot

| Perintah | Keterangan |
|----------|-----------|
| `menu` | Menu utama |
| `.admin` | Panel admin (owner only) |
| `.saldo` | Cek saldo |
| `.cek <orderId>` | Cek status pembayaran |
| `batal` / `0` | Batalkan proses |

## Menu User

```
1 → Order Akun VPN
2 → Trial Gratis 30 menit
3 → Top Up Saldo (QRIS Pakasir)
4 → My Account
5 → Cek Saldo
6 → Kontak Admin
```

## Fitur

- ✅ Order SSH, VMess, VLess, Trojan, ZivPN
- ✅ Trial 30 menit gratis
- ✅ Top Up Saldo via QRIS Pakasir
- ✅ Payment checker otomatis (8 detik)
- ✅ Countdown QRIS tiap 2 menit
- ✅ Cek status bayar manual (.cek)
- ✅ My Account (10 akun terbaru)
- ✅ Notif expired 3 hari & 1 hari sebelum
- ✅ Auto-delete akun expired dari server (tiap 6 jam)
- ✅ Admin panel: add saldo, set reseller, add server, broadcast, cari user
- ✅ Database SQLite (tidak perlu MySQL)
- ✅ Session-based menu (numbered, tanpa tombol)
- ✅ Pairing code (tanpa scan QR)
