// handler.js — Session-based message router (async/await)
'use strict';

const fs   = require('fs');
const path = require('path');
const { db, dbRun, dbGet, dbAll, dbRunSync } = require('./data/db');

/* ── Session state per user ── */
const sessions = new Map();
function getSession(id)              { if (!sessions.has(id)) sessions.set(id, { state: 'IDLE', data: {} }); return sessions.get(id); }
function setSession(id, state, data) { sessions.set(id, { state, data: data || {} }); }
function clearSession(id)            { sessions.set(id, { state: 'IDLE', data: {} }); }

/* ── Helpers ── */
function getAvars() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'data', '.avars.json'), 'utf8')); }
  catch { return global.avars || {}; }
}
function getServers() {
  try { const p = require.resolve('./data/server'); delete require.cache[p]; return require('./data/server'); }
  catch { return []; }
}
function formatRp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

function getHarga(role, type) {
  const av = getAvars();
  const r  = (role === 'reseller' || role === 'admin') ? 'reseller' : 'members';
  return av.harga?.[r]?.[type] || 3000;
}

/* ── Kirim pesan ── */
function send(bot, jid, text) {
  return bot.sendMessage(jid, { text }).catch(e => console.error('[SEND]', e.message));
}
module.exports.send = send;

/* ── DB helpers ── */
async function ensureUser(phoneId) {
  await dbRun("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'members')", [phoneId]);
  return dbGet('SELECT * FROM users WHERE chat_id=?', [phoneId]);
}
async function getUser(phoneId) {
  return dbGet('SELECT * FROM users WHERE chat_id=?', [phoneId]);
}

/* ── Label ── */
const PROTO_LABEL  = { SSH:'⚪ SSH/OpenVPN', VMESS:'🔵 xRay VMess', VLESS:'🟡 xRay VLess', TROJAN:'🟠 xRay Trojan', ZIVPN:'🟢 UDP ZivPN' };
const PROTO_SCRIPT = { SSH:'buatSSH', VMESS:'buatVME', VLESS:'buatVLE', TROJAN:'buatTRO', ZIVPN:'buatZIVPN' };

/* ─────────────────────────────────────────────
   TEKS MENU
───────────────────────────────────────────── */
function txtMenu(user) {
  const avars = getAvars();
  return `╔══════════════════╗
║  ${avars.bot_name || 'BOT VPN WA'}
╚══════════════════╝

👤 Role   : *${(user?.role||'members').toUpperCase()}*
💰 Saldo  : *${formatRp(user?.saldo||0)}*

*MENU UTAMA*
1️⃣  Order Akun VPN
2️⃣  Trial Gratis (30 menit)
3️⃣  Top Up Saldo
4️⃣  My Account
5️⃣  Cek Saldo
6️⃣  Kontak Admin

Balas dengan *angka* pilihan kamu.`;
}

function txtOrderProto() {
  return `╔══════════════════╗
║  ORDER AKUN VPN
╚══════════════════╝

Pilih protokol:
1️⃣  SSH / OpenVPN
2️⃣  xRay VMess
3️⃣  xRay VLess
4️⃣  xRay Trojan
5️⃣  UDP ZivPN

0️⃣  Kembali`;
}

function txtOrderServer(servers) {
  let t = `╔══════════════════╗\n║  PILIH SERVER\n╚══════════════════╝\n\n`;
  servers.forEach((s, i) => {
    const slot = s.limit ? `${s.used||0}/${s.limit}` : '∞';
    t += `${i+1}️⃣  ${s.name||s.ip} (${slot} slot)\n`;
  });
  return t + `\n0️⃣  Kembali`;
}

function txtOrderDays() {
  return `╔══════════════════╗
║  DURASI AKTIF
╚══════════════════╝

1️⃣  1 hari
2️⃣  7 hari
3️⃣  30 hari
4️⃣  Ketik manual (contoh: 14)

0️⃣  Kembali`;
}

function txtLimitIp(role) {
  const isResellerPlus = role === 'reseller' || role === 'admin';
  let t = `╔══════════════════╗\n║  LIMIT IP\n╚══════════════════╝\n\n`;
  t += isResellerPlus
    ? `1️⃣  1 IP  (gratis)\n2️⃣  5 IP  (gratis)\n3️⃣  10 IP (gratis)`
    : `1️⃣  1 IP  (gratis)\n2️⃣  2 IP  (+Rp 500/akun)\n3️⃣  3 IP  (+Rp 1.000/akun)`;
  return t + `\n\n0️⃣  Kembali`;
}

function txtTopup() {
  return `╔══════════════════╗
║  TOP UP SALDO
╚══════════════════╝

1️⃣  Rp 10.000
2️⃣  Rp 20.000
3️⃣  Rp 50.000
4️⃣  Rp 100.000
5️⃣  Nominal lain

0️⃣  Kembali`;
}

function txtAdminMenu(stats) {
  const avars = getAvars();
  return `╔══════════════════╗
║  ADMIN PANEL
╚══════════════════╝

📦 Order hari ini : *${stats.orders||0}*
💰 Income hari ini: *${formatRp(stats.income||0)}*
🖥  Server aktif  : *${getServers().length}*

*MENU ADMIN:*
1️⃣  Add Saldo User
2️⃣  Set Reseller
3️⃣  Tambah Server
4️⃣  Daftar Server
5️⃣  Broadcast
6️⃣  Cari User

0️⃣  Keluar`;
}

/* ─────────────────────────────────────────────
   CREATE ACCOUNT
───────────────────────────────────────────── */
async function doCreateAccount(bot, jid, phoneId, sessionData) {
  const { protocol, server, days, limitIp, totalHarga } = sessionData;
  const { executeScriptRemote, increaseServerUsage } = require('./services/ssh-exec');

  const ts       = Date.now();
  const username = `wa${phoneId.slice(-6)}${ts.toString().slice(-4)}`;
  const password = Math.random().toString(36).slice(2, 10);

  let args;
  if (protocol === 'SSH')                           args = [username, password, limitIp, days];
  else if (['VMESS','VLESS','TROJAN'].includes(protocol)) args = [username, days, 0, limitIp];
  else if (protocol === 'ZIVPN')                    args = [password, days, limitIp];

  await send(bot, jid, `⏳ Membuat akun *${PROTO_LABEL[protocol]}*...\n_Mohon tunggu 10-30 detik._`);

  executeScriptRemote(server.ip, PROTO_SCRIPT[protocol], args, async (err, rawOutput) => {
    if (err) {
      return send(bot, jid, `❌ Gagal membuat akun: ${err.message}\nHubungi admin.`);
    }

    const expiredAt = new Date(Date.now() + days * 86400000).toISOString().slice(0,19).replace('T',' ');
    const uname     = protocol === 'ZIVPN' ? password : username;

    dbRunSync(
      "INSERT INTO transactions (chat_id, order_id, amount, status, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', ?, ?, ?, ?)",
      [phoneId, `${protocol}-${ts}`, totalHarga, protocol, uname, expiredAt, server.ip]
    );
    increaseServerUsage(server.ip);

    /* Notif admin */
    const avars = getAvars();
    if (avars.owner_phone) {
      send(bot, `${avars.owner_phone.replace(/[^0-9]/g,'')}@s.whatsapp.net`,
        `🔔 *AKUN BARU DIBUAT*\n\n📦 ${PROTO_LABEL[protocol]}\n👤 ${uname}\n📱 WA: ${phoneId}\n💰 ${formatRp(totalHarga)}`
      ).catch(() => {});
    }

    const lines  = (rawOutput || '').split('\n').filter(l => l.trim() && !l.includes('RESULT_START') && !l.includes('RESULT_END'));
    const output = lines.slice(0, 20).join('\n');

    send(bot, jid,
`✅ *AKUN BERHASIL DIBUAT!*

📦 Protokol : *${PROTO_LABEL[protocol]}*
👤 Username : \`${uname}\`${protocol === 'SSH' ? `\n🔑 Password : \`${password}\`` : ''}
📅 Expired  : *${expiredAt.slice(0,10)}*
💰 Total    : *${formatRp(totalHarga)}*

${output ? '```\n' + output + '\n```' : ''}
Ketik *menu* untuk kembali.`
    );
  });
}
module.exports.doCreateAccount = doCreateAccount;

/* ─────────────────────────────────────────────
   MAIN HANDLER
───────────────────────────────────────────── */
module.exports = async function handler(bot, msg) {
  if (!msg.message) return;
  if (msg.key.fromMe) return;

  const jid     = msg.key.remoteJid;
  if (jid.endsWith('@g.us')) return; // private only

  const body = (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text || ''
  ).trim();
  if (!body) return;

  const senderFull = msg.key.participant || jid;
  const phoneId    = senderFull.replace('@s.whatsapp.net','').replace(/[^0-9]/g,'');
  const avars      = getAvars();
  const ownerPhone = (avars.owner_phone||'').replace(/[^0-9]/g,'');
  const isOwner    = phoneId === ownerPhone;

  const user    = await ensureUser(phoneId);
  const role    = user?.role || 'members';
  const isAdmin = role === 'admin' || isOwner;

  const sess  = getSession(phoneId);
  const lower = body.toLowerCase();

  /* ── Global shortcuts ── */
  if (lower === 'menu' || lower === '.menu' || lower === 'start' || lower === '/start') {
    clearSession(phoneId);
    return send(bot, jid, txtMenu(user));
  }
  if (lower === 'batal' || lower === 'cancel' || body === '0') {
    clearSession(phoneId);
    return send(bot, jid, '✅ Dibatalkan.\n\nKetik *menu* untuk kembali.');
  }
  if (lower === '.saldo' || lower === 'saldo') {
    return send(bot, jid, `💰 Saldo kamu: *${formatRp(user?.saldo||0)}*`);
  }
  if (lower.startsWith('.cek ')) {
    const orderId = body.slice(5).trim();
    const { handleManualCek } = require('./services/paymentChecker');
    return handleManualCek(bot, jid, phoneId, orderId);
  }
  if ((lower === '.admin' || lower === '/admin') && isAdmin) {
    const today = new Date().toISOString().slice(0,10);
    const stats = await dbGet("SELECT COUNT(*) as orders, SUM(amount) as income FROM transactions WHERE status='completed' AND created_at LIKE ?", [`${today}%`]);
    setSession(phoneId, 'ADMIN_MENU');
    return send(bot, jid, txtAdminMenu(stats||{}));
  }

  /* ── State machine ── */
  switch (sess.state) {

    /* ═══ IDLE ═══ */
    case 'IDLE': {
      if (body === '1') { setSession(phoneId, 'ORDER_PROTO'); return send(bot, jid, txtOrderProto()); }
      if (body === '2') { setSession(phoneId, 'TRIAL_PROTO'); return send(bot, jid, txtTrialProto()); }
      if (body === '3') { setSession(phoneId, 'TOPUP_MENU'); return send(bot, jid, txtTopup()); }
      if (body === '4') { clearSession(phoneId); return sendMyAccount(bot, jid, phoneId); }
      if (body === '5') { return send(bot, jid, `💰 Saldo kamu: *${formatRp(user?.saldo||0)}*`); }
      if (body === '6') { return send(bot, jid, `📞 *Kontak Admin*\n\nWA: wa.me/${ownerPhone}`); }
      return send(bot, jid, txtMenu(user));
    }

    /* ═══ ORDER FLOW ═══ */
    case 'ORDER_PROTO': {
      const map = {'1':'SSH','2':'VMESS','3':'VLESS','4':'TROJAN','5':'ZIVPN'};
      if (!map[body]) return send(bot, jid, '❌ Pilih 1-5 atau 0 untuk batal.');
      const servers = getServers();
      if (!servers.length) { clearSession(phoneId); return send(bot, jid, '❌ Belum ada server. Hubungi admin.'); }
      setSession(phoneId, 'ORDER_SERVER', { protocol: map[body] });
      return send(bot, jid, txtOrderServer(servers));
    }

    case 'ORDER_SERVER': {
      const servers = getServers();
      const idx = parseInt(body) - 1;
      if (isNaN(idx) || idx < 0 || idx >= servers.length) return send(bot, jid, `❌ Pilih 1-${servers.length} atau 0 batal.`);
      if (servers[idx].limit && (servers[idx].used||0) >= servers[idx].limit) return send(bot, jid, '❌ Server penuh. Pilih server lain.');
      setSession(phoneId, 'ORDER_DAYS', { ...sess.data, serverIdx: idx });
      return send(bot, jid, txtOrderDays());
    }

    case 'ORDER_DAYS': {
      const dmap = {'1':1,'2':7,'3':30};
      let days = dmap[body] || parseInt(body);
      if (!days || days < 1 || days > 365) return send(bot, jid, '❌ Durasi tidak valid (1-365 hari).');
      setSession(phoneId, 'ORDER_LIMITIP', { ...sess.data, days });
      return send(bot, jid, txtLimitIp(role));
    }

    case 'ORDER_LIMITIP': {
      const isResellerPlus = role === 'reseller' || role === 'admin';
      const ipMap = isResellerPlus
        ? {'1':1,'2':5,'3':10}
        : {'1':1,'2':2,'3':3};
      const ip = ipMap[body];
      if (!ip) return send(bot, jid, '❌ Pilih 1, 2, atau 3.');
      const { protocol, serverIdx, days } = sess.data;
      const servers    = getServers();
      const server     = servers[serverIdx];
      const harga      = getHarga(role, protocol);
      const extraIp    = isResellerPlus ? 0 : Math.max(0, ip - 1) * 500;
      const totalHarga = (harga * days) + (extraIp * days);
      const konfData   = { protocol, server, serverIdx, days, limitIp: ip, totalHarga, harga };

      const konfText =
`╔══════════════════╗
║  KONFIRMASI ORDER
╚══════════════════╝

📦 Protokol : *${PROTO_LABEL[protocol]}*
🖥  Server  : *${server.name||server.ip}*
⏱  Durasi  : *${days} hari*
📱 Limit IP : *${ip} IP*
💰 Harga/hr : *${formatRp(harga)}*
🧮 Total    : *${formatRp(totalHarga)}*

Saldo kamu: *${formatRp(user?.saldo||0)}*

1️⃣  Bayar pakai Saldo
2️⃣  Bayar pakai QRIS
0️⃣  Batal`;

      setSession(phoneId, 'ORDER_CONFIRM', konfData);
      return send(bot, jid, konfText);
    }

    case 'ORDER_CONFIRM': {
      if (body === '1') {
        const { totalHarga } = sess.data;
        const u = await getUser(phoneId);
        if ((u?.saldo||0) < totalHarga) {
          clearSession(phoneId);
          return send(bot, jid, `❌ Saldo tidak cukup.\n\nSaldo: *${formatRp(u?.saldo||0)}*\nDibutuhkan: *${formatRp(totalHarga)}*\n\nKetik *menu* → Top Up Saldo.`);
        }
        await dbRun('UPDATE users SET saldo = saldo - ? WHERE chat_id=?', [totalHarga, phoneId]);
        const data = { ...sess.data };
        clearSession(phoneId);
        return doCreateAccount(bot, jid, phoneId, data);
      }
      if (body === '2') {
        const data = { ...sess.data };
        clearSession(phoneId);
        const { generateQRIS } = require('./services/qris');
        return generateQRIS(bot, jid, phoneId, data.totalHarga, {
          productType:   data.protocol,
          productName:   PROTO_LABEL[data.protocol],
          accountCreate: data
        });
      }
      return send(bot, jid, '❌ Pilih 1 (Saldo), 2 (QRIS), atau 0 (Batal).');
    }

    /* ═══ TRIAL FLOW ═══ */
    case 'TRIAL_PROTO': {
      const map = {'1':'SSH','2':'VMESS','3':'VLESS','4':'TROJAN','5':'ZIVPN'};
      if (!map[body]) return send(bot, jid, '❌ Pilih 1-5 atau 0 untuk batal.');
      const servers = getServers();
      if (!servers.length) { clearSession(phoneId); return send(bot, jid, '❌ Belum ada server. Hubungi admin.'); }
      const protocol  = map[body];
      const server    = servers[0];
      const ts        = Date.now();
      const username  = `tri${phoneId.slice(-5)}${ts.toString().slice(-3)}`;
      const password  = Math.random().toString(36).slice(2, 8);
      const scriptMap = { SSH:'triallSSH', VMESS:'triallVME', VLESS:'triallVLE', TROJAN:'triallTRO', ZIVPN:'triallZIV' };
      const { executeScriptRemote } = require('./services/ssh-exec');
      const args = protocol === 'SSH' ? [username, password] : protocol === 'ZIVPN' ? [password] : [username];

      clearSession(phoneId);
      await send(bot, jid, `⏳ Membuat akun *TRIAL* ${PROTO_LABEL[protocol]}...\n_30 menit aktif, harap tunggu._`);

      executeScriptRemote(server.ip, scriptMap[protocol]||'triallSSH', args, (err, output) => {
        if (err) return send(bot, jid, `❌ Gagal trial: ${err.message}`);
        const uname = protocol === 'ZIVPN' ? password : username;
        send(bot, jid,
`✅ *TRIAL BERHASIL!*

📦 ${PROTO_LABEL[protocol]}
👤 Username : \`${uname}\`${protocol === 'SSH' ? `\n🔑 Password : \`${password}\`` : ''}
⏰ Durasi   : *30 menit*

${output ? '```\n' + output.split('\n').slice(0,15).join('\n') + '\n```' : ''}
Setelah 30 menit akun otomatis mati.
Ketik *menu* untuk order akun berbayar.`
        );
      });
      break;
    }

    /* ═══ TOPUP FLOW ═══ */
    case 'TOPUP_MENU': {
      const nomMap = {'1':10000,'2':20000,'3':50000,'4':100000};
      if (nomMap[body]) {
        clearSession(phoneId);
        const { generateQRIS } = require('./services/qris');
        return generateQRIS(bot, jid, phoneId, nomMap[body], { productType:'TOPUP', productName:'Top Up Saldo' });
      }
      if (body === '5') { setSession(phoneId, 'TOPUP_CUSTOM'); return send(bot, jid, '💰 Masukkan nominal (minimal Rp 5.000):\n_Contoh: 25000_'); }
      return send(bot, jid, '❌ Pilih 1-5 atau 0 untuk batal.');
    }

    case 'TOPUP_CUSTOM': {
      const amount = parseInt(body.replace(/[^0-9]/g,''));
      if (!amount || amount < 5000) return send(bot, jid, '❌ Minimal Rp 5.000. Coba lagi atau ketik *batal*.');
      clearSession(phoneId);
      const { generateQRIS } = require('./services/qris');
      return generateQRIS(bot, jid, phoneId, amount, { productType:'TOPUP', productName:'Top Up Saldo' });
    }

    /* ═══ ADMIN FLOW ═══ */
    case 'ADMIN_MENU': {
      if (!isAdmin) { clearSession(phoneId); return; }
      if (body === '1') { setSession(phoneId, 'ADMIN_ADDSALDO_PHONE'); return send(bot, jid, '📱 Masukkan nomor WA user (format 628xxx):'); }
      if (body === '2') { setSession(phoneId, 'ADMIN_SETRESELLER'); return send(bot, jid, '📱 Masukkan nomor WA user yang akan dijadikan reseller:'); }
      if (body === '3') { setSession(phoneId, 'ADMIN_ADDSERVER'); return send(bot, jid, '🖥 Format: _nama|ip|username|password|limit_\n\nContoh:\nIDN-Server1|103.x.x.x|root|pass123|60'); }
      if (body === '4') {
        const servers = getServers();
        if (!servers.length) { clearSession(phoneId); return send(bot, jid, '📋 Belum ada server terdaftar.'); }
        let t = '📋 *Daftar Server:*\n\n';
        servers.forEach((s,i) => { t += `${i+1}. *${s.name||s.ip}* | ${s.ip} | Slot: ${s.used||0}/${s.limit||'∞'}\n`; });
        clearSession(phoneId);
        return send(bot, jid, t);
      }
      if (body === '5') { setSession(phoneId, 'ADMIN_BROADCAST'); return send(bot, jid, '📢 Ketik pesan broadcast:'); }
      if (body === '6') { setSession(phoneId, 'ADMIN_CARIUSER'); return send(bot, jid, '🔍 Masukkan nomor WA user (628xxx):'); }
      clearSession(phoneId);
      return send(bot, jid, '✅ Keluar admin panel.\n\nKetik *menu* untuk menu utama.');
    }

    case 'ADMIN_ADDSALDO_PHONE': {
      if (!isAdmin) { clearSession(phoneId); return; }
      setSession(phoneId, 'ADMIN_ADDSALDO_AMOUNT', { targetPhone: body.replace(/[^0-9]/g,'') });
      return send(bot, jid, `💰 Jumlah saldo untuk *${sess.data.targetPhone||body}*:`);
    }

    case 'ADMIN_ADDSALDO_AMOUNT': {
      if (!isAdmin) { clearSession(phoneId); return; }
      const amount = parseInt(body.replace(/[^0-9]/g,''));
      if (!amount || amount <= 0) return send(bot, jid, '❌ Jumlah tidak valid. Coba lagi.');
      const target = sess.data.targetPhone;
      await dbRun("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'members')", [target]);
      await dbRun('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [amount, target]);
      const u2 = await dbGet('SELECT saldo FROM users WHERE chat_id=?', [target]);
      clearSession(phoneId);
      send(bot, `${target}@s.whatsapp.net`, `✅ Saldo kamu ditambah *${formatRp(amount)}*!\nSaldo baru: *${formatRp(u2?.saldo||0)}*`).catch(()=>{});
      return send(bot, jid, `✅ Saldo *${target}* +${formatRp(amount)}\nSaldo sekarang: *${formatRp(u2?.saldo||0)}*`);
    }

    case 'ADMIN_SETRESELLER': {
      if (!isAdmin) { clearSession(phoneId); return; }
      const target = body.replace(/[^0-9]/g,'');
      await dbRun("INSERT OR IGNORE INTO users (chat_id, saldo, role) VALUES (?, 0, 'members')", [target]);
      await dbRun("UPDATE users SET role='reseller' WHERE chat_id=?", [target]);
      clearSession(phoneId);
      send(bot, `${target}@s.whatsapp.net`, `✅ Kamu di-upgrade jadi *RESELLER*!\nKetik *menu* untuk order dengan harga reseller.`).catch(()=>{});
      return send(bot, jid, `✅ *${target}* berhasil dijadikan reseller.`);
    }

    case 'ADMIN_ADDSERVER': {
      if (!isAdmin) { clearSession(phoneId); return; }
      const parts = body.split('|').map(p => p.trim());
      if (parts.length < 4) return send(bot, jid, '❌ Format salah. Gunakan: nama|ip|user|pass|limit');
      const [name, ip, username, pass, limitStr] = parts;
      const limit   = parseInt(limitStr) || 100;
      const servers = getServers();
      servers.push({ name, ip, username, pass, limit, used: 0 });
      const f = path.join(__dirname, 'data', 'server.js');
      fs.writeFileSync(f, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
      delete require.cache[require.resolve('./data/server')];
      clearSession(phoneId);
      return send(bot, jid, `✅ Server *${name}* (${ip}) berhasil ditambahkan!`);
    }

    case 'ADMIN_BROADCAST': {
      if (!isAdmin) { clearSession(phoneId); return; }
      const pesan = body;
      const users = await dbAll("SELECT chat_id FROM users WHERE chat_id IS NOT NULL");
      clearSession(phoneId);
      let ok = 0, fail = 0;
      for (const u of users) {
        try { await send(bot, `${u.chat_id}@s.whatsapp.net`, `📢 *BROADCAST*\n\n${pesan}`); ok++; await new Promise(r=>setTimeout(r,1200)); }
        catch { fail++; }
      }
      return send(bot, jid, `✅ Broadcast selesai!\n✅ Terkirim: ${ok}\n❌ Gagal: ${fail}`);
    }

    case 'ADMIN_CARIUSER': {
      if (!isAdmin) { clearSession(phoneId); return; }
      const target = body.replace(/[^0-9]/g,'');
      const [u2, trx] = await Promise.all([
        dbGet('SELECT * FROM users WHERE chat_id=?', [target]),
        dbGet("SELECT COUNT(*) as c, SUM(amount) as s FROM transactions WHERE chat_id=? AND status='completed'", [target])
      ]);
      clearSession(phoneId);
      if (!u2) return send(bot, jid, `❌ User *${target}* tidak ditemukan.`);
      return send(bot, jid,
`🔍 *Info User*

📱 WA     : ${target}
👑 Role   : *${(u2.role||'members').toUpperCase()}*
💰 Saldo  : *${formatRp(u2.saldo||0)}*
📦 Order  : ${trx?.c||0} transaksi
💵 Total  : *${formatRp(trx?.s||0)}*
📅 Join   : ${u2.created_at?.slice(0,10)||'-'}`);
    }

    default: {
      clearSession(phoneId);
      return send(bot, jid, txtMenu(user));
    }
  }
};

/* ── My Account ── */
async function sendMyAccount(bot, jid, phoneId) {
  const user = await dbGet('SELECT * FROM users WHERE chat_id=?', [phoneId]);
  const rows = await dbAll(
    "SELECT product_type, username, expired_at FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('','TOPUP') ORDER BY expired_at DESC LIMIT 10",
    [phoneId]
  );
  const now = new Date();
  let txt = '';
  if (!rows.length) {
    txt = '_Belum ada akun aktif._\n';
  } else {
    rows.forEach(r => {
      const exp  = new Date(r.expired_at);
      const sisa = exp > now ? Math.ceil((exp - now) / 86400000) : 0;
      const ico  = sisa > 3 ? '🟢' : sisa > 0 ? '🟡' : '🔴';
      const base = (r.product_type||'').replace('RENEW ','').replace('TRIAL-','');
      txt += `${ico} *${base}* | ${r.username||'-'} | ${r.expired_at?.slice(0,10)||'-'} (${sisa}hr)\n`;
    });
  }
  return send(bot, jid,
`╔══════════════════╗
║  MY ACCOUNT
╚══════════════════╝

💰 Saldo : *${formatRp(user?.saldo||0)}*
👑 Role  : *${(user?.role||'members').toUpperCase()}*
📅 Join  : ${user?.created_at?.slice(0,10)||'-'}

📦 *Akun (10 terbaru):*
${txt}
Ketik *menu* untuk kembali.`);
}

function txtTrialProto() {
  return `╔══════════════════╗
║  TRIAL GRATIS
╚══════════════════╝

Pilih protokol (30 menit):
1️⃣  SSH / OpenVPN
2️⃣  xRay VMess
3️⃣  xRay VLess
4️⃣  xRay Trojan
5️⃣  UDP ZivPN

0️⃣  Kembali`;
}
