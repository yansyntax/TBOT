'use strict';

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

const SCRIPT_DIR = path.join(__dirname, '..', 'shell_script');

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch (e) { return []; }
}

function readAllScripts() {
  if (!fs.existsSync(SCRIPT_DIR)) return [];
  return fs.readdirSync(SCRIPT_DIR)
    .filter(f => fs.statSync(path.join(SCRIPT_DIR, f)).isFile())
    .map(f => ({
      name: f,
      content: fs.readFileSync(path.join(SCRIPT_DIR, f), 'utf8')
    }));
}

function apiRequest(serverConfig, endpoint, method, body) {
  return new Promise((resolve, reject) => {
    const baseUrl = serverConfig.apiUrl;
    const url = new URL(baseUrl + endpoint);
    const isHttps = url.protocol === 'https:';
    const transport = isHttps ? https : http;

    const postData = body ? JSON.stringify(body) : '';

    const options = {
      hostname: url.hostname,
      port:     url.port || (isHttps ? 443 : 80),
      path:     url.pathname,
      method:   method,
      headers:  {
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(postData),
        'X-Api-Token':   serverConfig.apiToken
      },
      timeout: 60000
    };

    const req = transport.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(data) });
        } catch (e) {
          reject(new Error('Respons tidak valid'));
        }
      });
    });

    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', (err) => reject(err));

    if (postData) req.write(postData);
    req.end();
  });
}

async function syncToServer(serverConfig) {
  const scripts = readAllScripts();
  if (scripts.length === 0) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: 'Tidak ada script untuk disync' };
  }

  try {
    const result = await apiRequest(serverConfig, '/api/sync', 'POST', { scripts });

    if (result.status === 401) {
      return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: 'Token tidak valid' };
    }

    return {
      server: serverConfig.name,
      ip: serverConfig.ip,
      status: 'ok',
      synced: result.data.synced,
      failed: result.data.failed,
      details: result.data.details
    };
  } catch (e) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: e.message };
  }
}

async function syncToAllServers() {
  const servers = getServers().filter(s => s.apiUrl && s.apiToken);
  if (servers.length === 0) {
    return { success: false, message: 'Tidak ada server dengan konfigurasi API' };
  }

  const results = await Promise.all(servers.map(s => syncToServer(s)));
  return { success: true, results };
}

async function listRemoteScripts(serverConfig) {
  try {
    const result = await apiRequest(serverConfig, '/api/scripts', 'GET', null);
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'ok', scripts: result.data.scripts };
  } catch (e) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: e.message };
  }
}

module.exports = { syncToServer, syncToAllServers, listRemoteScripts, readAllScripts };
