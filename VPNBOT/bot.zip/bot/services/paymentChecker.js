// services/paymentChecker.js - v3.0 — 10min expiry
'use strict';

const axios  = require('axios');
const fs     = require('fs');
const path   = require('path');
const db     = require('../data/db');
const { calculateBonus } = require('./promo');
const { doCreateAccountAfterPayment, doRenewAccountAfterPayment } = require('./ssh-exec');

let config = {};
try {
  config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (err) {
  console.error('[paymentChecker] ❌ Gagal load .avars.json:', err.message);
}

const PAKASIR_BASE   = 'https://app.pakasir.com/api';
const PROJECT        = config.pakasir_slug;
const API_KEY        = process.env.PAKASIR_API_KEY || config.pakasir_api_key;
const BOT_NAME       = config.bot_name || 'BOT';
const OWNER_ID       = Number(config.owner_id) || 0;
const CHECK_INTERVAL = 8000;
const QRIS_TTL_MS    = 10 * 60 * 1000;  // 10 menit

if (!PROJECT || !API_KEY) {
  console.warn('[paymentChecker] ⚠️ pakasir_slug/api_key kosong — payment checker dinonaktifkan.');
}

const pendingOrders = new Map();

function addPendingOrder(orderId, info) {
  pendingOrders.set(orderId, { ...info, createdAt: Date.now(), status: 'pending' });
}

function removePendingOrder(orderId) {
  pendingOrders.delete(orderId);
}

/* ══════════════════════════════════════════
   NOTIFIKASI REAL-TIME KE ADMIN
══════════════════════════════════════════ */
function notifyAdmin(bot, orderId, info, type) {
  if (!OWNER_ID) return;

  const typeLabels = {
    topup:   '💰 TOP UP SALDO',
    create:  '📦 BELI AKUN',
    renew:   '🔄 PERPANJANG AKUN'
  };

  const nominal = info.amount || 0;
  const waktu   = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

  const msg =
`🔔 <b>PEMBAYARAN MASUK!</b>

📌 Tipe     : <b>${typeLabels[type] || type}</b>
🆔 Chat ID  : <code>${info.chatId}</code>
🧾 Order ID : <code>${orderId}</code>
💵 Nominal  : <b>Rp ${nominal.toLocaleString('id-ID')}</b>
⏰ Waktu    : ${waktu} WIB`;

  bot.sendMessage(OWNER_ID, msg, { parse_mode: 'HTML' }).catch(() => {});
}

async function fetchPaymentStatus(orderId, amount) {
  try {
    const url = `${PAKASIR_BASE}/transactiondetail?project=${PROJECT}&amount=${amount}&order_id=${orderId}&api_key=${API_KEY}`;
    const res = await axios.get(url, { timeout: 8000 });
    return res.data?.transaction || { status: 'not_found' };
  } catch (e) {
    return { status: 'error' };
  }
}

async function processCompletedPayment(bot, orderId, info) {
  removePendingOrder(orderId);

  /* cancel QRIS countdown */
  try {
    const { clearQrisCountdown } = require('./qris');
    clearQrisCountdown(orderId);
  } catch (e) {}

  if (info.accountCreate) {
    db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
    notifyAdmin(bot, orderId, info, 'create');
    doCreateAccountAfterPayment(bot, info.chatId, info.accountCreate);
    return;
  }

  if (info.accountRenew) {
    db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
    notifyAdmin(bot, orderId, info, 'renew');
    doRenewAccountAfterPayment(bot, info.chatId, info.accountRenew);
    return;
  }

  // Topup saldo
  const finalAmount = calculateBonus(info.amount);

  db.run(
    "INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))",
    [info.chatId],
    () => {
      db.run('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [finalAmount, info.chatId], () => {
        db.get('SELECT saldo, role FROM users WHERE chat_id=?', [info.chatId], (err, row) => {
          if (!row) return;
          const newSaldo = row.saldo || 0;
          if (newSaldo >= 20000 && row.role !== 'reseller' && row.role !== 'admin') {
            db.run("UPDATE users SET role='reseller' WHERE chat_id=?", [info.chatId]);
          }

          bot.sendMessage(info.chatId,
`✅ <b>PEMBAYARAN BERHASIL!</b>

🧾 Order ID    : <code>${orderId}</code>
💰 Nominal     : Rp ${info.amount.toLocaleString('id-ID')}${finalAmount > info.amount ? `\n🎁 Bonus       : +Rp ${(finalAmount - info.amount).toLocaleString('id-ID')}` : ''}
💳 Total Masuk : <b>Rp ${finalAmount.toLocaleString('id-ID')}</b>
💰 Saldo Baru  : <b>Rp ${newSaldo.toLocaleString('id-ID')}</b>

Ketik /menu untuk mulai order.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
        });
      });
    }
  );

  db.run("UPDATE transactions SET status='completed' WHERE order_id=?", [orderId]);
  notifyAdmin(bot, orderId, info, 'topup');
}

async function handleRefresh(bot, chatId, orderId) {
  const info = pendingOrders.get(orderId);
  if (!info) {
    return bot.sendMessage(chatId, '❌ Order tidak ditemukan atau sudah kadaluarsa.');
  }

  const tx = await fetchPaymentStatus(orderId, info.amount);

  if (tx.status === 'completed') {
    await processCompletedPayment(bot, orderId, info);
  } else {
    const statusMap = {
      error:     'Gagal cek (coba lagi)',
      not_found: 'Belum terbayar',
      canceled:  'Dibatalkan',
      expired:   'Kadaluarsa'
    };
    bot.sendMessage(chatId,
      `⏳ <b>Status: ${statusMap[tx.status] || 'Pending'}</b>\n\nBelum ada pembayaran masuk.\nBayar dulu, lalu klik tombol cek lagi.`,
      { parse_mode: 'HTML' }
    );
  }
}

function startPaymentChecker(bot) {
  if (!PROJECT || !API_KEY) return;
  console.log(`[${BOT_NAME}] ✅ Payment checker aktif (interval ${CHECK_INTERVAL}ms)`);

  setInterval(async () => {
    if (pendingOrders.size === 0) return;

    const checks = [];
    for (const [orderId, info] of pendingOrders.entries()) {
      const ageMs = Date.now() - info.createdAt;
      if (ageMs > QRIS_TTL_MS) {
        pendingOrders.delete(orderId);
        db.run("UPDATE transactions SET status='expired' WHERE order_id=?", [orderId]);
        try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (e) {}
        bot.sendMessage(info.chatId,
          `❌ Order <code>${orderId}</code> kadaluarsa (10 menit terlewat).`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
        continue;
      }
      checks.push([orderId, info]);
    }

    for (const [orderId, info] of checks) {
      const tx = await fetchPaymentStatus(orderId, info.amount);
      if (tx.status === 'completed') {
        await processCompletedPayment(bot, orderId, info);
      } else if (tx.status === 'canceled' || tx.status === 'expired') {
        removePendingOrder(orderId);
        db.run("UPDATE transactions SET status=? WHERE order_id=?", [tx.status, orderId]);
        try { const { clearQrisCountdown } = require('./qris'); clearQrisCountdown(orderId); } catch (e) {}
        bot.sendMessage(info.chatId,
          `❌ Order <code>${orderId}</code> dibatalkan/kadaluarsa.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
    }
  }, CHECK_INTERVAL);
}

module.exports = { addPendingOrder, removePendingOrder, handleRefresh, startPaymentChecker };
