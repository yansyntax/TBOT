#!/bin/bash
echo "============================================"
echo "  Setup VPS Bot API"
echo "============================================"

if [ -z "$1" ]; then
  API_TOKEN=$(openssl rand -hex 24)
  echo "[+] Token API baru dibuat: $API_TOKEN"
else
  API_TOKEN=$1
  echo "[+] Menggunakan token yang diberikan"
fi

API_PORT=${2:-3456}

INSTALL_DIR="/opt/vps-bot-api"
mkdir -p "$INSTALL_DIR/shell_script"

echo "[+] Menyalin file..."
cp server.js "$INSTALL_DIR/"
cp package.json "$INSTALL_DIR/"

if [ -d "../botyan/shell_script" ]; then
  cp ../botyan/shell_script/* "$INSTALL_DIR/shell_script/"
  echo "[+] Shell scripts disalin dari botyan"
elif [ -d "./shell_script" ]; then
  cp ./shell_script/* "$INSTALL_DIR/shell_script/"
  echo "[+] Shell scripts disalin dari folder lokal"
else
  echo "[!] PERHATIAN: Salin shell scripts Anda ke $INSTALL_DIR/shell_script/ secara manual"
fi

cd "$INSTALL_DIR"
echo "[+] Menginstall dependencies..."
npm install --production

cat > /etc/systemd/system/vps-bot-api.service <<EOF
[Unit]
Description=VPS Bot API Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment=API_TOKEN=$API_TOKEN
Environment=API_PORT=$API_PORT
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable vps-bot-api
systemctl start vps-bot-api

echo ""
echo "============================================"
echo "  SETUP SELESAI!"
echo "============================================"
echo ""
echo "  API URL  : http://$(hostname -I | awk '{print $1}'):$API_PORT"
echo "  API Token: $API_TOKEN"
echo ""
echo "  Simpan token ini untuk dipakai di bot!"
echo ""
echo "  Cek status: systemctl status vps-bot-api"
echo "  Cek log   : journalctl -u vps-bot-api -f"
echo ""
echo "  Test API:"
echo "  curl -H 'X-Api-Token: $API_TOKEN' http://localhost:$API_PORT/api/ping"
echo "============================================"
