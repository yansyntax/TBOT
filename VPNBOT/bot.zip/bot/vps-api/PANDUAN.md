# Panduan Setup VPS Bot API

## Langkah 1: Upload file ke VPS

Upload folder `vps-api/` ke VPS Anda:
```bash
scp -r vps-api/ root@45.119.200.227:/root/vps-api/
```

## Langkah 2: Salin shell scripts ke API server

```bash
ssh root@45.119.200.227
cd /root/vps-api
mkdir -p shell_script
cp /path/to/botyan/shell_script/* shell_script/
```

ATAU jika shell scripts sudah ada di VPS (misal di `/root/botyan/shell_script/`):
```bash
cp /root/botyan/shell_script/* /root/vps-api/shell_script/
```

## Langkah 3: Jalankan setup

```bash
cd /root/vps-api
chmod +x setup.sh
bash setup.sh
```

Setup akan:
- Install dependencies
- Generate token API secara otomatis
- Membuat systemd service agar jalan otomatis
- Menampilkan token yang harus disimpan

## Langkah 4: Catat token API

Setelah setup, akan muncul pesan seperti:
```
API Token: abc123def456...
```

**SIMPAN TOKEN INI!** Token ini akan dipakai di konfigurasi bot.

## Langkah 5: Update konfigurasi bot

Di file bot `data/server.js`, tambahkan `apiUrl` dan `apiToken`:

```javascript
const servers = [
  {
    "name": "SG",
    "ip": "45.119.200.227",
    "apiUrl": "http://45.119.200.227:3456",
    "apiToken": "TOKEN_DARI_SETUP",
    "limit": 90,
    "used": 19
  }
];
```

Dengan konfigurasi ini, bot akan otomatis menggunakan API (bukan SSH).

## Langkah 6: Test

```bash
curl -X POST http://45.119.200.227:3456/api/ping \
  -H "X-Api-Token: TOKEN_ANDA"
```

## Troubleshooting

Cek status: `systemctl status vps-bot-api`
Cek log: `journalctl -u vps-bot-api -f`
Restart: `systemctl restart vps-bot-api`
