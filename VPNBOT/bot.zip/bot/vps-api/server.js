const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(express.json({ limit: '5mb' }));

const PORT = process.env.API_PORT || 3456;
const TOKEN = process.env.API_TOKEN || '';

if (!TOKEN) {
  console.error('[API] API_TOKEN belum diset! Jalankan: export API_TOKEN="token_anda"');
  process.exit(1);
}

const SCRIPT_DIR = path.join(__dirname, 'shell_script');

function authMiddleware(req, res, next) {
  const token = req.headers['x-api-token'] || req.body.token;
  if (!token || token !== TOKEN) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Token tidak valid' });
  }
  next();
}

app.use('/api', authMiddleware);

app.get('/api/ping', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.post('/api/exec', (req, res) => {
  const { script, args } = req.body;

  if (!script) {
    return res.status(400).json({ error: 'BAD_REQUEST', message: 'Parameter "script" wajib diisi' });
  }

  if (!/^[a-zA-Z0-9_]+$/.test(script)) {
    return res.status(400).json({ error: 'BAD_REQUEST', message: 'Nama script tidak valid' });
  }

  const scriptPath = path.join(SCRIPT_DIR, script);
  if (!fs.existsSync(scriptPath)) {
    return res.status(404).json({ error: 'SCRIPT_NOT_FOUND', message: `Script "${script}" tidak ditemukan` });
  }

  const safeArgs = (args || []).map(a => String(a));
  const timeout = 30000;

  const child = execFile('bash', [scriptPath, ...safeArgs], { timeout }, (err, stdout, stderr) => {
    if (err) {
      if (err.killed) {
        return res.status(504).json({ error: 'TIMEOUT', message: 'Script timeout (30 detik)', output: stdout || '' });
      }
      const output = (stdout || '') + (stderr || '');
      return res.json({ success: false, exitCode: err.code, output: output.trim() });
    }

    const output = ((stdout || '') + (stderr || '')).trim();
    res.json({ success: true, exitCode: 0, output });
  });
});

app.post('/api/sync', (req, res) => {
  const { scripts } = req.body;

  if (!scripts || !Array.isArray(scripts) || scripts.length === 0) {
    return res.status(400).json({ error: 'BAD_REQUEST', message: 'Parameter "scripts" (array) wajib diisi' });
  }

  if (!fs.existsSync(SCRIPT_DIR)) {
    fs.mkdirSync(SCRIPT_DIR, { recursive: true });
  }

  const results = [];
  for (const item of scripts) {
    if (!item.name || !item.content) {
      results.push({ name: item.name || '?', status: 'skipped', reason: 'nama atau isi kosong' });
      continue;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(item.name)) {
      results.push({ name: item.name, status: 'skipped', reason: 'nama tidak valid' });
      continue;
    }

    try {
      const filePath = path.join(SCRIPT_DIR, item.name);
      fs.writeFileSync(filePath, item.content, 'utf8');
      fs.chmodSync(filePath, '755');
      results.push({ name: item.name, status: 'ok' });
    } catch (e) {
      results.push({ name: item.name, status: 'error', reason: e.message });
    }
  }

  const ok = results.filter(r => r.status === 'ok').length;
  const failed = results.filter(r => r.status !== 'ok').length;
  res.json({ success: true, synced: ok, failed, details: results });
});

app.get('/api/scripts', (req, res) => {
  if (!fs.existsSync(SCRIPT_DIR)) {
    return res.json({ scripts: [] });
  }
  const files = fs.readdirSync(SCRIPT_DIR).filter(f => {
    const full = path.join(SCRIPT_DIR, f);
    return fs.statSync(full).isFile();
  });
  res.json({ scripts: files });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[API] VPS Bot API running on port ${PORT}`);
  console.log(`[API] Script directory: ${SCRIPT_DIR}`);
  console.log(`[API] Token: ${TOKEN.slice(0, 4)}****`);
});
