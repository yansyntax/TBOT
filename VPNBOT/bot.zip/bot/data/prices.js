module.exports = {
  members: {
    ssh:      { perDay: 200 },
    vmess:    { perDay: 200 },
    vless:    { perDay: 200 },
    trojan:   { perDay: 200 },
    udpzivpn: { perDay: 200 }
  },
  reseller: {
    ssh:      { perDay: 150 },
    vmess:    { perDay: 150 },
    vless:    { perDay: 150 },
    trojan:   { perDay: 150 },
    udpzivpn: { perDay: 150 }
  }
};
