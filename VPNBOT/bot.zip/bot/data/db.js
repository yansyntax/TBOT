const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('[DB] ❌ Gagal buka database:', err.message);
  } else {
    console.log('[DB] ✅ Database ready:', dbPath);
  }
});

db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL');
  db.run('PRAGMA synchronous = NORMAL');
  db.run('PRAGMA cache_size = 4000');
  db.run('PRAGMA temp_store = MEMORY');
  db.run('PRAGMA mmap_size = 268435456');
  db.run('PRAGMA busy_timeout = 5000');

  db.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  db.run(`ALTER TABLE transactions ADD COLUMN username TEXT DEFAULT ''`, () => {});
  db.run(`ALTER TABLE transactions ADD COLUMN expired_at TEXT DEFAULT ''`, () => {});
  db.run(`ALTER TABLE transactions ADD COLUMN server_ip TEXT DEFAULT ''`, () => {});

  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  db.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);
});

module.exports = db;
