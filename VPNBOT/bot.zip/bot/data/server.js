const servers = [
  {
    "name": "SG",
    "ip": "45.119.200.227",
    "username": "root",
    "pass": "7RQWmmum",
    "limit": 90,
    "used": 19
  }
];

module.exports = servers;