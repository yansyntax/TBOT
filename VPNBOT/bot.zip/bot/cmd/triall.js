// cmd/triall.js - v5.1 — ISP detection, domain fallback ZivPN, payload SSH
'use strict';

const db   = require('../data/db');
const { executeScriptRemote, increaseServerUsage } = require('../services/ssh-exec');
const { autoMenu } = require('../utils/autoMenu');

const TRIAL_MINUTES = 30;
const DEFAULT_IP    = 1;
const DEFAULT_QUOTA = 1;

/* ── Prefix per protokol ── */
const PREFIX = { ssh: 'ssh', vmess: 'vme', vless: 'vle', trojan: 'tro', zivpn: 'ziv' };
const EMOJI  = { ssh: '⚪', vmess: '🔵', vless: '🟡', trojan: '🟠', zivpn: '🟢' };

const TYPE_CONFIG = {
  ssh:    { label: 'SSH / OpenVPN', scriptName: 'triallSSH', productType: 'TRIAL-SSH'   },
  vmess:  { label: 'xRay VMess',   scriptName: 'triallVME', productType: 'TRIAL-VMESS'  },
  vless:  { label: 'xRay VLess',   scriptName: 'triallVLE', productType: 'TRIAL-VLESS'  },
  trojan: { label: 'xRay Trojan',  scriptName: 'triallTRO', productType: 'TRIAL-TROJAN' },
  zivpn:  { label: 'UDP ZivPN',    scriptName: 'triallZIV', productType: 'TRIAL-ZIVPN'  }
};

/* ── Generate random string (huruf kecil + angka) ── */
function randomStr(n) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = '';
  for (let i = 0; i < n; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

/* ── Generate username dengan prefix protokol ── */
function generateUsername(type) {
  return `${PREFIX[type] || 'usr'}_${randomStr(8)}`;
}

/* ── Generate password acak (huruf besar+kecil+angka, 8 karakter) ── */
function generatePassword() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let s = '';
  for (let i = 0; i < 8; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

/* ── Cek cooldown trial untuk member (1 per 24 jam) ── */
function checkAnyTrialCooldown(chatId) {
  return new Promise(resolve => {
    const cutoff = new Date(Date.now() - 24 * 3600000)
      .toISOString().slice(0, 19).replace('T', ' ');
    db.get(
      "SELECT id FROM transactions WHERE chat_id=? AND product_type LIKE 'TRIAL%' AND created_at > ?",
      [chatId, cutoff],
      (err, row) => resolve(!!row)
    );
  });
}

/* ── Bersihkan noise SSH ── */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

/* ── Parse output shell script: ambil blok TRIAL_RESULT_START...END ── */
function parseResult(raw) {
  const out = {};
  let inBlock = false;
  for (const line of raw.split('\n')) {
    const t = line.trim();
    if (t === 'TRIAL_RESULT_START') { inBlock = true; continue; }
    if (t === 'TRIAL_RESULT_END')   { inBlock = false; continue; }
    if (!inBlock) continue;
    const idx = t.indexOf(':');
    if (idx < 0) continue;
    const key = t.slice(0, idx).trim();
    const val = t.slice(idx + 1).trim();
    if (key && val) out[key] = val;
  }
  return out;
}

/* ── Format kartu hasil trial yang bagus untuk Telegram ── */
function buildResultCard(type, r) {
  const em    = EMOJI[type]  || '🔵';
  const label = TYPE_CONFIG[type]?.label?.toUpperCase() || type.toUpperCase();

  let card = `${em} <b>AKUN TRIAL ${label}</b>\n\n`;
  card += `┌─────────────────┐\n`;

  if (r.USERNAME) card += `│ 🆔 Username : <code>${r.USERNAME}</code>\n`;
  if (r.PASSWORD && type === 'ssh')   card += `│ 🔑 Password : <code>${r.PASSWORD}</code>\n`;
  if (r.PASSWORD && type === 'zivpn') card += `│ 🔑 Password : <code>${r.PASSWORD}</code>\n`;
  if (r.UUID)   card += `│ 🔑 UUID     : <code>${r.UUID.substring(0, 18)}...</code>\n`;
  if (r.DOMAIN)  card += `│ 🌐 Domain   : <code>${r.DOMAIN}</code>\n`;
  if (r.ISP)     card += `│ 🏢 ISP      : ${r.ISP}\n`;
  if (r.COUNTRY) card += `│ 🌍 Country  : ${r.COUNTRY}\n`;

  if (r.PORT_TLS || r.PORT_HTTP || r.PORT_UDP) {
    card += `├─────────────────┤\n`;
    if (r.PORT_TLS)  card += `│ 🔌 Port TLS : <b>${r.PORT_TLS}</b>\n`;
    if (r.PORT_HTTP) card += `│ 🔌 Port HTTP: <b>${r.PORT_HTTP}</b>\n`;
    if (r.PORT_UDP)  card += `│ 🔌 Port UDP : <b>${r.PORT_UDP}</b>\n`;
  }

  if (r.LIMIT_IP || r.QUOTA) {
    card += `├─────────────────┤\n`;
    if (r.LIMIT_IP) card += `│ 🔢 Limit IP : <b>${r.LIMIT_IP}</b>\n`;
    if (r.QUOTA)    card += `│ 💾 Quota    : <b>${r.QUOTA} GB</b>\n`;
  }

  card += `├─────────────────┤\n`;
  card += `│ ⏱ Aktif   : <b>${TRIAL_MINUTES} menit</b>\n`;
  if (r.EXPIRED) card += `│ 📅 Expired : <b>${r.EXPIRED}</b>\n`;
  card += `└─────────────────┘\n`;
  card += `\n🆓 <b>GRATIS!</b>`;

  /* Payload SSH (tap untuk copy) */
  if (type === 'ssh' && r.DOMAIN) {
    const payload =
      `GET / HTTP/1.1[crlf]Host: ${r.DOMAIN}[crlf][crlf]` +
      `PATCH / HTTP/1.4[crlf]Host: ${r.DOMAIN}[crlf]` +
      `Upgrade: websocket[crlf][crlf][split]HTTP/ 69[crlf][crlf]`;
    card += `\n\n<b>📦 PAYLOAD SSH</b> <i>(tap untuk copy)</i>\n<code>${payload}</code>`;
  }

  /* Link koneksi (VMess/VLess/Trojan) — ditampilkan terpisah agar tidak berantakan */
  if (r.TLS_LINK || r.WS_LINK || r.GRPC_LINK || r.XHTTP_LINK) {
    card += `\n\n<b>🔗 LINK KONEKSI</b> <i>(tap untuk copy)</i>`;
    if (r.TLS_LINK)   card += `\n\n<b>[TLS]</b>\n<code>${r.TLS_LINK}</code>`;
    if (r.WS_LINK)    card += `\n\n<b>[WS]</b>\n<code>${r.WS_LINK}</code>`;
    if (r.GRPC_LINK)  card += `\n\n<b>[gRPC]</b>\n<code>${r.GRPC_LINK}</code>`;
    if (r.XHTTP_LINK) card += `\n\n<b>[XHTTP]</b>\n<code>${r.XHTTP_LINK}</code>`;
  }

  return card;
}

/* ── Progress bar ── */
function buildProgress(pct, label) {
  const filled = Math.round(pct / 10);
  const bar    = '▰'.repeat(filled) + '▱'.repeat(10 - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

/* ══════════════════════════════════════════
   INIT TRIAL — tidak ada input dari user
══════════════════════════════════════════ */
async function initTriall(bot, chatId, userStates, type, menuMsgId) {
  /* Role check */
  const user = await new Promise(r =>
    db.get('SELECT role FROM users WHERE chat_id=?', [chatId], (e, v) => r(v || { role: 'members' }))
  );
  const role = user.role || 'members';

  const stateData = userStates.get(chatId);
  const serverIp  = stateData?.serverIp;
  if (!serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih. Ketik /menu');

  const servers = require('../data/server');
  const server  = servers.find(s => s.ip === serverIp);
  if (!server)  return bot.sendMessage(chatId, '❌ Server tidak ditemukan.');

  if (menuMsgId) bot.deleteMessage(chatId, menuMsgId).catch(() => {});

  const cfg = TYPE_CONFIG[type];
  if (!cfg) return bot.sendMessage(chatId, '❌ Tipe tidak dikenali.');

  /* Cooldown: admin & reseller bebas, member max 1x/24jam */
  if (role === 'members') {
    const onCooldown = await checkAnyTrialCooldown(chatId);
    if (onCooldown) {
      return bot.sendMessage(chatId,
        `❌ <b>Kamu sudah pernah trial dalam 24 jam terakhir.</b>\n\nLimit: 1 akun trial per 24 jam untuk Members.\nCoba lagi besok!\n\n💡 <i>Upgrade ke Reseller untuk trial tanpa batas.</i>`,
        { parse_mode: 'HTML' }
      );
    }
  }

  /* Auto-generate username & password */
  const username = generateUsername(type);
  const password = generatePassword();

  const em = EMOJI[type] || '🔵';

  /* Tampilkan kartu awal dengan username yang sudah di-generate */
  const startCard =
    `${em} <b>MEMULAI TRIAL ${cfg.label.toUpperCase()}</b>\n\n` +
    `┌─────────────────┐\n` +
    `│ 🆔 Username : <code>${username}</code>\n` +
    (type === 'ssh' ? `│ 🔑 Password : <code>${password}</code>\n` : '') +
    (type === 'zivpn' ? `│ 🔑 Password : <code>${username}</code>\n` : '') +
    `│ ⏱ Durasi   : <b>${TRIAL_MINUTES} menit</b>\n` +
    `│ 🔢 Limit IP : <b>${DEFAULT_IP}</b>\n` +
    (type !== 'ssh' ? `│ 💾 Quota    : <b>${DEFAULT_QUOTA} GB</b>\n` : '') +
    `└─────────────────┘\n\n⏳ <i>Mohon tunggu...</i>`;

  const msg = await bot.sendMessage(chatId, startCard, { parse_mode: 'HTML' }).catch(() => null);
  if (!msg) return;

  await executeTriall(bot, chatId, userStates, {
    type, serverIp, role,
    msgId: msg.message_id,
    data: { username, password }
  }, cfg);
}

/* ══════════════════════════════════════════
   EXECUTE — animasi progress + jalankan script
══════════════════════════════════════════ */
async function executeTriall(bot, chatId, userStates, st, cfg) {
  userStates.delete(chatId);

  const { msgId } = st;

  await bot.editMessageText(
    buildProgress(0, '⏳ <b>Menghubungkan ke server...</b>'),
    { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
  ).catch(() => {});

  let animStep = 1;
  const FRAMES = [
    { pct: 30, label: '🔄 <b>Membuat akun trial...</b>' },
    { pct: 60, label: '⚙️ <b>Mengonfigurasi...</b>'     },
    { pct: 75, label: '📝 <b>Menyimpan data...</b>'     }
  ];

  const animInterval = setInterval(() => {
    if (animStep - 1 < FRAMES.length) {
      const f = FRAMES[animStep - 1];
      bot.editMessageText(buildProgress(f.pct, f.label), {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
      }).catch(() => {});
      animStep++;
    }
  }, 2500);

  /* Susun args sesuai script */
  let args = [];
  if (st.type === 'ssh')        args = [st.data.username, st.data.password, DEFAULT_IP, TRIAL_MINUTES];
  else if (st.type === 'zivpn') args = [st.data.username, TRIAL_MINUTES, DEFAULT_IP];
  else                          args = [st.data.username, TRIAL_MINUTES, DEFAULT_QUOTA, DEFAULT_IP];

  executeScriptRemote(st.serverIp, cfg.scriptName, args, (err, rawOutput) => {
    clearInterval(animInterval);
    const output = cleanOutput(rawOutput);

    if (err) {
      console.error('[triall] ❌', err.message);
      return bot.editMessageText(
        `❌ <b>Gagal buat trial</b>\n\n<code>${err.message}</code>\n\nHubungi admin.`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => bot.sendMessage(chatId, '❌ Gagal buat trial: ' + err.message));
    }

    const hasResult = /TRIAL_RESULT_START[\s\S]*TRIAL_RESULT_END/.test(output || '');
    if (!hasResult) {
      return bot.editMessageText(
        `❌ <b>Gagal buat trial</b>\n\n<code>${output || 'Output script kosong'}</code>\n\nHubungi admin.`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => bot.sendMessage(chatId, '❌ Gagal buat trial: ' + (output || 'Output script kosong')));
    }

    /* Parse hasil script */
    const result = parseResult(output);
    /* Fallback domain: jika script tidak bisa baca domain (misal ZivPN), pakai serverIp */
    if (!result.DOMAIN) result.DOMAIN = st.serverIp;

    const expiredAt = new Date(Date.now() + TRIAL_MINUTES * 60000)
      .toISOString().slice(0, 19).replace('T', ' ');

    /* Simpan ke DB */
    const uname = st.data.username || '-';
    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, 0, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
      [chatId, `${cfg.productType}-${Date.now()}`, cfg.productType, uname, expiredAt, st.serverIp]
    );

    increaseServerUsage(st.serverIp);

    /* Tampilkan 100% dulu, lalu detail */
    bot.editMessageText(
      buildProgress(100, '✅ <b>Akun Trial Berhasil Dibuat!</b>'),
      { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
    ).catch(() => {}).finally(() => {
      setTimeout(() => {
        const detailText = hasResult
          ? buildResultCard(st.type, result)
          : `✅ <b>Akun Trial ${cfg.label} Berhasil!</b>\n\n` +
            `🆔 Username : <code>${uname}</code>\n` +
            (st.type === 'ssh' ? `🔑 Password : <code>${st.data.password}</code>\n` : '') +
            `⏱ Aktif    : <b>${TRIAL_MINUTES} menit</b>\n` +
            `🔢 Limit IP : <b>${DEFAULT_IP}</b>\n` +
            `💾 Quota    : <b>${DEFAULT_QUOTA} GB</b>\n` +
            `🆓 <b>GRATIS!</b>`;

        bot.editMessageText(detailText, {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
        }).catch(() => bot.sendMessage(chatId, detailText, {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
        }));

        autoMenu(bot, chatId, 1500);
      }, 800);
    });
  });
}

/* ── handleStep tetap ada sebagai no-op (tidak ada steps lagi) ── */
async function handleStep(bot, chatId, text, userStates) {
  // Tidak ada lagi input steps untuk trial
}

module.exports = {
  triallSSH:    (bot, chatId, userStates, msgId) => initTriall(bot, chatId, userStates, 'ssh',    msgId),
  triallVMess:  (bot, chatId, userStates, msgId) => initTriall(bot, chatId, userStates, 'vmess',  msgId),
  triallVLess:  (bot, chatId, userStates, msgId) => initTriall(bot, chatId, userStates, 'vless',  msgId),
  triallTrojan: (bot, chatId, userStates, msgId) => initTriall(bot, chatId, userStates, 'trojan', msgId),
  triallZivpn:  (bot, chatId, userStates, msgId) => initTriall(bot, chatId, userStates, 'zivpn',  msgId),
  handleStep
};
