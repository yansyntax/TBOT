// services/promo.js
'use strict';

const fs   = require('fs');
const path = require('path');

const file   = path.join(__dirname, '../data/promo.json');
let _cache   = null;

function getPromo() {
  if (!_cache) {
    try { _cache = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { _cache = { active: false, bonus: 10, min: 20000 }; }
  }
  return _cache;
}

function setPromo(status) {
  const data  = getPromo();
  data.active = status;
  _cache      = data;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function calculateBonus(amount) {
  const promo = getPromo();
  if (!promo.active) return amount;
  const min         = Number(promo.min) || 0;
  const bonusPct    = Number(promo.bonus) || 0;
  if (amount < min) return amount;
  const bonus = Math.floor(amount * bonusPct / 100);
  return amount + bonus;
}

module.exports = { getPromo, setPromo, calculateBonus };
