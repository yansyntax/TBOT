// services/ssh-exec.js - v3.0 — progress animation, filter output, autoMenu
'use strict';

const { Client } = require('ssh2');
const db      = require('../data/db');
const fs      = require('fs');
const path    = require('path');
const { autoMenu } = require('../utils/autoMenu');

function formatRupiah(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch (e) { return []; }
}

/* Bersihkan noise dari output SSH */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

function buildProgress(pct, label) {
  const total  = 10;
  const filled = Math.round(pct / 10);
  const bar    = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const servers      = getServers();
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error(`Server ${serverIp} tidak terdaftar`));

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`Script ${scriptFileName} tidak ditemukan`));

  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  const conn = new Client();

  const safeArgs = args.map(a => String(a).replace(/'/g, "'\\''"));
  const isRoot   = (serverConfig.username || 'root') === 'root';
  const tmpFile  = `/tmp/_bot_${Date.now()}`;
  const runCmd   = isRoot
    ? `bash ${tmpFile} ${safeArgs.join(' ')}`
    : `echo '${(serverConfig.pass || '').replace(/'/g, "'\\''")}' | sudo -S bash ${tmpFile} ${safeArgs.join(' ')}`;
  const command  = `cat > ${tmpFile} && ${runCmd}; rm -f ${tmpFile}`;

  const TIMEOUT = setTimeout(() => {
    conn.end();
    callback(new Error('Koneksi SSH timeout (30 detik)'));
  }, 30000);

  conn.on('ready', () => {
    conn.exec(command, (err, stream) => {
      if (err) {
        clearTimeout(TIMEOUT);
        conn.end();
        return callback(err);
      }

      let output = '';
      stream.on('data', data => { output += data; });
      stream.stderr.on('data', data => {
        const line = data.toString();
        if (!line.includes('[sudo]') && !line.includes('password for')) output += line;
      });
      stream.on('close', () => {
        clearTimeout(TIMEOUT);
        conn.end();
        callback(null, output.trim());
      });
      stream.end(scriptContent);
    });
  })
  .on('keyboard-interactive', (_n, _i, _l, prompts, finish) => {
    finish(prompts.map(() => serverConfig.pass));
  })
  .on('error', err => {
    clearTimeout(TIMEOUT);
    callback(err);
  })
  .connect({
    host:         serverIp,
    port:         22,
    username:     serverConfig.username || 'root',
    password:     serverConfig.pass,
    tryKeyboard:  true,
    readyTimeout: 25000
  });
}

function increaseServerUsage(serverIp) {
  const servers = getServers();
  const server  = servers.find(s => s.ip === serverIp);
  if (!server) return;
  server.used  = (server.used || 0) + 1;
  server.limit = server.limit || 999;
  const file = path.join(__dirname, '../data/server.js');
  fs.writeFileSync(file, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
}

function doCreateAccountAfterPayment(bot, chatId, accountCreate) {
  const { type, serverIp, data, scriptName, productType, label, role, totalHarga, pricePerDay } = accountCreate;

  let args = [];
  if (type === 'ssh')   args = [data.username, data.password, data.limitIp, data.days];
  else if (['vmess', 'vless', 'trojan'].includes(type)) args = [data.username, data.days, data.quota ?? 1, data.limitIp];
  else if (type === 'zivpn') args = [data.password, data.days, data.limitIp];

  /* Kirim pesan loading dengan progress bar */
  bot.sendMessage(chatId,
    buildProgress(0, `⏳ <b>Pembayaran diterima!</b>\nMembuat akun <b>${label}</b>...`),
    { parse_mode: 'HTML' }
  ).then(loadMsg => {
    const msgId     = loadMsg?.message_id;
    let animStep    = 1;
    const FRAMES = [
      { pct: 30, label: `🔄 <b>Membuat akun ${label}...</b>` },
      { pct: 60, label: '⚙️ <b>Mengonfigurasi protokol...</b>' },
      { pct: 70, label: '📝 <b>Menyimpan konfigurasi...</b>'   }
    ];

    const animInterval = setInterval(() => {
      if (animStep - 1 < FRAMES.length && msgId) {
        const f = FRAMES[animStep - 1];
        bot.editMessageText(buildProgress(f.pct, f.label), {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
        }).catch(() => {});
        animStep++;
      }
    }, 2500);

    executeScriptRemote(serverIp, scriptName, args, (err, rawOutput) => {
      clearInterval(animInterval);
      const output = cleanOutput(rawOutput);

      if (err) {
        console.error('[doCreateAccountAfterPayment] ❌', err.message);
        const errText = `❌ Pembayaran diterima, tapi gagal buat akun.\n\n<code>${err.message}</code>\n\nHubungi admin untuk tindak lanjut.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      const expiredAt = new Date(Date.now() + data.days * 86400000)
        .toISOString().slice(0, 19).replace('T', ' ');
      const username = data.username || data.password || '-';

      db.run(
        "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
        [chatId, `${productType}-${Date.now()}`, totalHarga, productType, username, expiredAt, serverIp]
      );

      increaseServerUsage(serverIp);

      const detailText =
        `✅ <b>${label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n` +
        (output ? `<pre>${output}</pre>\n\n` : '') +
        `💰 Harga/Hari : ${formatRupiah(pricePerDay)}\n` +
        `📅 Masa Aktif : ${data.days} hari\n` +
        `🧮 Total      : ${formatRupiah(totalHarga)}`;

      const doneKeyboard = { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] };

      /* Step 1: Tampilkan 100% */
      const edit100 = msgId
        ? bot.editMessageText(buildProgress(100, `✅ <b>${label.toUpperCase()} BERHASIL!</b>`), { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' })
        : Promise.resolve();

      edit100.catch(() => {}).finally(() => {
        /* Step 2: Setelah 800ms tampilkan detail */
        setTimeout(() => {
          const showDetail = msgId
            ? bot.editMessageText(detailText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', reply_markup: doneKeyboard })
            : bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard });

          showDetail.catch(() => bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard }).catch(() => {}));

          /* Step 3: Kirim quick-action menu setelah 1.5 detik */
          autoMenu(bot, chatId, 1500);
        }, 800);
      });
    });
  }).catch(err => {
    console.error('[doCreateAccountAfterPayment] sendMessage error:', err.message);
    /* Fallback tanpa progress */
    executeScriptRemote(serverIp, scriptName, args, (err2, rawOutput) => {
      if (err2) return bot.sendMessage(chatId, `❌ Gagal buat akun: ${err2.message}`, { parse_mode: 'HTML' });
      const output = cleanOutput(rawOutput);
      bot.sendMessage(chatId,
        `✅ <b>${label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n` + (output ? `<pre>${output}</pre>` : ''),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] } }
      ).catch(() => {});
      autoMenu(bot, chatId, 1500);
    });
  });
}

function doRenewAccountAfterPayment(bot, chatId, accountRenew) {
  const { account, data, scriptName, label, totalHarga, pricePerDay } = accountRenew;

  let args = [];
  if (account.product_type === 'SSH')   args = [account.username, data.days, data.limitIp];
  else if (['VMESS', 'VLESS', 'TROJAN'].includes(account.product_type)) args = [account.username, data.days, data.quota ?? 1, data.limitIp];
  else if (account.product_type === 'ZIVPN') args = [account.username, data.days, data.limitIp];

  bot.sendMessage(chatId,
    buildProgress(0, `⏳ <b>Pembayaran diterima!</b>\nMeng-extend akun <b>${account.username}</b>...`),
    { parse_mode: 'HTML' }
  ).then(loadMsg => {
    const msgId  = loadMsg?.message_id;
    let animStep = 1;
    const FRAMES = [
      { pct: 30, label: `🔄 <b>Memperpanjang ${account.username}...</b>` },
      { pct: 60, label: '⚙️ <b>Memperbarui konfigurasi...</b>'           },
      { pct: 70, label: '📝 <b>Menyimpan perubahan...</b>'               }
    ];

    const animInterval = setInterval(() => {
      if (animStep - 1 < FRAMES.length && msgId) {
        const f = FRAMES[animStep - 1];
        bot.editMessageText(buildProgress(f.pct, f.label), {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
        }).catch(() => {});
        animStep++;
      }
    }, 2500);

    executeScriptRemote(account.server_ip, scriptName, args, (err, rawOutput) => {
      clearInterval(animInterval);
      const output = cleanOutput(rawOutput);

      if (err) {
        console.error('[doRenewAccountAfterPayment] ❌', err.message);
        const errText = `❌ Pembayaran diterima, tapi gagal extend.\n\n<code>${err.message}</code>\n\nHubungi admin.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      const expiredAt = new Date(Date.now() + data.days * 86400000)
        .toISOString().slice(0, 19).replace('T', ' ');

      db.run(
        "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
        [chatId, `RENEW-${account.product_type}-${Date.now()}`, totalHarga,
         `RENEW ${account.product_type}`, account.username, expiredAt, account.server_ip]
      );

      const detailText =
        `✅ <b>EXTEND ${account.product_type} BERHASIL!</b>\n\n` +
        (output ? `<pre>${output}</pre>\n\n` : '') +
        `🆔 Username : ${account.username}\n` +
        `📅 Extend   : ${data.days} hari\n` +
        `🧮 Total    : ${formatRupiah(totalHarga)}`;

      const doneKeyboard = { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] };

      const edit100 = msgId
        ? bot.editMessageText(buildProgress(100, `✅ <b>EXTEND BERHASIL!</b>`), { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' })
        : Promise.resolve();

      edit100.catch(() => {}).finally(() => {
        setTimeout(() => {
          const showDetail = msgId
            ? bot.editMessageText(detailText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', reply_markup: doneKeyboard })
            : bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard });

          showDetail.catch(() => bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard }).catch(() => {}));
          autoMenu(bot, chatId, 1500);
        }, 800);
      });
    });
  }).catch(err => {
    console.error('[doRenewAccountAfterPayment] sendMessage error:', err.message);
    executeScriptRemote(account.server_ip, scriptName, args, (err2, rawOutput) => {
      if (err2) return bot.sendMessage(chatId, `❌ Gagal extend: ${err2.message}`, { parse_mode: 'HTML' });
      const output = cleanOutput(rawOutput);
      bot.sendMessage(chatId,
        `✅ <b>EXTEND ${account.product_type} BERHASIL!</b>\n\n` + (output ? `<pre>${output}</pre>` : ''),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] } }
      ).catch(() => {});
      autoMenu(bot, chatId, 1500);
    });
  });
}

module.exports = {
  executeScriptRemote,
  increaseServerUsage,
  doCreateAccountAfterPayment,
  doRenewAccountAfterPayment
};
